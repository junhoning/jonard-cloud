export { b as buttonAccent, a as buttonDanger, c as buttonDangerSecondary, d as buttonGhost, e as buttonGhostDanger, f as buttonPrimary, g as buttonSecondary, h as calendarDayStates, i as calendarNavigation, j as controlField, s as stateCenteredLayout, k as stateDescriptionText, l as stateTitleText, m as surfaceCard, n as surfacePanel, o as surfaceRaised, p as surfaceRounded } from './states-KHk94m3R.js';
import * as react_jsx_runtime from 'react/jsx-runtime';
import React__default, { ComponentProps } from 'react';
import * as styled_components_dist_types from 'styled-components/dist/types';
import * as styled_components from 'styled-components';

type Space = number | string;
declare function space(value?: Space): string | undefined;
declare function numberOrString(value?: number | string): string | undefined;

type BoxProps = React__default.HTMLAttributes<HTMLDivElement> & {
    as?: React__default.ElementType;
    display?: string;
    padding?: Space;
    gap?: Space;
    width?: string | number;
    height?: string | number;
    align?: string;
    justify?: string;
    direction?: string;
    wrap?: string;
};
declare function Box({ as, display, padding, gap, width, height, align, justify, direction, wrap, ...props }: BoxProps): react_jsx_runtime.JSX.Element;

declare function Stack({ gap, align, justify, as, ...props }: React__default.HTMLAttributes<HTMLDivElement> & {
    gap?: Space;
    align?: string;
    justify?: string;
    as?: React__default.ElementType;
}): react_jsx_runtime.JSX.Element;
declare function Inline({ gap, align, justify, wrap, as, ...props }: React__default.HTMLAttributes<HTMLDivElement> & {
    gap?: Space;
    align?: string;
    justify?: string;
    wrap?: string;
    as?: React__default.ElementType;
}): react_jsx_runtime.JSX.Element;
declare function Grid({ gap, columns, minItemWidth, ...props }: React__default.HTMLAttributes<HTMLDivElement> & {
    gap?: Space;
    columns?: string;
    minItemWidth?: string | number;
}): react_jsx_runtime.JSX.Element;
declare function Container({ maxWidth, padding, ...props }: React__default.HTMLAttributes<HTMLDivElement> & {
    maxWidth?: string | number;
    padding?: Space;
}): react_jsx_runtime.JSX.Element;

declare const toneColor: {
    readonly default: "var(--ig-color-text-primary)";
    readonly secondary: "var(--ig-color-text-secondary)";
    readonly muted: "var(--ig-color-text-muted)";
    readonly soft: "var(--ig-color-text-soft)";
    readonly accent: "var(--ig-color-accent-soft)";
    readonly success: "var(--ig-color-status-running-text)";
    readonly warning: "var(--ig-color-status-draft-text)";
    readonly danger: "var(--ig-color-status-failed-text)";
};
declare const fontFamilyVar: {
    readonly default: undefined;
    readonly mono: "var(--ig-font-mono)";
};
declare const fontWeightVar: {
    readonly regular: "var(--ig-font-weight-regular)";
    readonly medium: "var(--ig-font-weight-medium)";
    readonly semibold: "var(--ig-font-weight-semibold)";
    readonly bold: "var(--ig-font-weight-bold)";
    readonly black: "var(--ig-font-weight-black)";
};
declare const letterSpacingVar: {
    readonly tight: "var(--ig-letter-spacing-tight)";
    readonly normal: "var(--ig-letter-spacing-normal)";
    readonly wide: "var(--ig-letter-spacing-wide)";
    readonly wider: "var(--ig-letter-spacing-wider)";
    readonly widest: "var(--ig-letter-spacing-widest)";
};
type Tone = keyof typeof toneColor;
type FontFamily = keyof typeof fontFamilyVar;
type FontWeightAlias = keyof typeof fontWeightVar;
type LetterSpacingAlias = keyof typeof letterSpacingVar;
type Align = 'left' | 'center' | 'right';
interface TextProps extends Omit<React__default.AllHTMLAttributes<HTMLElement>, 'as' | 'size'> {
    as?: React__default.ElementType;
    tone?: Tone;
    size?: string;
    weight?: number | FontWeightAlias;
    align?: Align;
    uppercase?: boolean;
    letterSpacing?: string | LetterSpacingAlias;
    fontFamily?: FontFamily;
    tabularNums?: boolean;
}
declare function Text({ as, tone, size, weight, align, uppercase, letterSpacing, fontFamily, tabularNums, ...props }: TextProps): react_jsx_runtime.JSX.Element;

declare function Heading({ level, ...props }: React__default.HTMLAttributes<HTMLHeadingElement> & {
    level?: 1 | 2 | 3 | 4;
}): react_jsx_runtime.JSX.Element;

/**
 * Named type scale primitives — design system 의 의미적 텍스트 스타일.
 *
 * | 토큰 | font-size | weight | 용도 |
 * |---|---|---|---|
 * | H1 | 5xl (28px) | 800 | Page hero title |
 * | H2 | 4xl (24px) | 700 | Section title |
 * | H3 | 2xl (18px) | 600 | Subsection title |
 * | H4 | xl  (16px) | 600 | Block title, dialog title |
 * | B1 | lg  (15px) | 400 | Body large — emphasis body |
 * | B2 | md  (14px) | 400 | Body medium — default body |
 * | B3 | sm  (13px) | 400 | Body small — dense table, secondary |
 * | C1 | xs  (12px) | 400 | Caption — meta, footnote |
 * | L1 | xs  (12px) | 600 | Label — uppercase, letter-spaced |
 *
 * Heading 은 의미적 h1~h4 element 로 렌더 (a11y). Body/Caption/Label 은 span 기본.
 * 기본 동작이 부족하면 underlying Heading/Text 의 props 전달 가능.
 *
 * 더 작은 텍스트 (10/11px) 는 type scale 에 없음. `<Text size="var(--ig-font-size-3xs)" />`
 * 또는 `2xs` 토큰 직접 사용 (mobile small label, icon-sized chip 등).
 */
type HeadingProps = ComponentProps<typeof Heading>;
declare function H1(props: Omit<HeadingProps, 'level'>): react_jsx_runtime.JSX.Element;
declare function H2(props: Omit<HeadingProps, 'level'>): react_jsx_runtime.JSX.Element;
declare function H3(props: Omit<HeadingProps, 'level'>): react_jsx_runtime.JSX.Element;
declare function H4(props: Omit<HeadingProps, 'level'>): react_jsx_runtime.JSX.Element;
declare function B1(props: Omit<TextProps, 'size'>): react_jsx_runtime.JSX.Element;
declare function B2(props: Omit<TextProps, 'size'>): react_jsx_runtime.JSX.Element;
declare function B3(props: Omit<TextProps, 'size'>): react_jsx_runtime.JSX.Element;
declare function C1(props: Omit<TextProps, 'size' | 'tone'>): react_jsx_runtime.JSX.Element;
declare function L1(props: Omit<TextProps, 'size' | 'weight' | 'uppercase' | 'letterSpacing'>): react_jsx_runtime.JSX.Element;

declare function Surface({ elevation, radius, ...props }: React__default.HTMLAttributes<HTMLDivElement> & {
    elevation?: 'panel' | 'raised' | 'card';
    radius?: Space;
}): react_jsx_runtime.JSX.Element;

declare const Divider: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLHRElement>, HTMLHRElement>, never>> & string;
declare const ScrollArea: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare function Icon({ size, ...props }: React__default.HTMLAttributes<HTMLSpanElement> & {
    size?: number;
}): react_jsx_runtime.JSX.Element;

interface SvgBboxRectProps extends Omit<React__default.SVGProps<SVGRectElement>, 'x' | 'y' | 'width' | 'height' | 'fill' | 'stroke'> {
    x: number;
    y: number;
    w: number;
    h: number;
    color: string;
    fillOpacity?: number;
    strokeWidth?: number;
}
/**
 * Bbox rectangle for annotation / measurement overlays.
 * Fill + stroke in `color`, with optional `fillOpacity`.
 * Use `vectorEffect="non-scaling-stroke"` for zoom-invariant stroke.
 */
declare function SvgBboxRect({ x, y, w, h, color, fillOpacity, strokeWidth, ...rest }: SvgBboxRectProps): react_jsx_runtime.JSX.Element;

interface SvgPointDotProps {
    cx: number;
    cy: number;
    rx: number;
    /** Optional. When omitted (or equal to `rx`), renders as `<circle r={rx}>`. */
    ry?: number;
    color: string;
    stroke?: string;
    strokeWidth?: number;
    vectorEffect?: 'non-scaling-stroke' | 'none';
    style?: React__default.CSSProperties;
    className?: string;
}
/**
 * Point dot. Renders `<circle>` when `rx === ry` (or `ry` omitted), else
 * `<ellipse>` — anisotropic `rx` / `ry` lets caller fix size in CSS pixels
 * under a non-square viewBox.
 */
declare function SvgPointDot({ cx, cy, rx, ry, color, stroke, strokeWidth, vectorEffect, style, className, }: SvgPointDotProps): react_jsx_runtime.JSX.Element;

interface SvgShapeLabelProps {
    /** Background rect width (px in label-local coord). */
    width: number;
    /** Background rect height (px in label-local coord). */
    height: number;
    /** Background fill color. */
    color: string;
    /** Background opacity. */
    opacity?: number;
    /** Background corner radius. */
    radius?: number;
    /** Label text. */
    text: React__default.ReactNode;
    /** Text horizontal padding. */
    padX?: number;
    /** Text vertical padding (baseline offset). */
    padY?: number;
    /** Text font size. */
    fontSize: number;
    /** Text fill (default white). */
    textColor?: string;
    /** Wrapping <g> transform (translate/scale) for placement + zoom-invariant scaling. */
    transform?: string;
}
/**
 * Label tag (background rect + text) for SVG annotations.
 * Wrapping <g transform> controls placement + zoom-invariant scaling.
 */
declare function SvgShapeLabel({ width, height, color, opacity, radius, text, padX, padY, fontSize, textColor, transform, }: SvgShapeLabelProps): react_jsx_runtime.JSX.Element;

interface SvgShapeHandleProps {
    cx: number;
    cy: number;
    rx: number;
    /** Optional. When omitted (or equal to `rx`), renders as `<circle r={rx}>`. */
    ry?: number;
    color: string;
    fill?: string;
    strokeWidth?: number;
    vectorEffect?: 'non-scaling-stroke' | 'none';
    style?: React__default.CSSProperties;
    className?: string;
}
/**
 * Resize handle dot for editable SVG shapes (bbox corners, polygon vertices).
 * Default fill is white with `color` stroke — standard "draggable handle" look.
 * Renders `<circle>` when `rx === ry` (or `ry` omitted), else `<ellipse>`.
 */
declare function SvgShapeHandle({ cx, cy, rx, ry, color, fill, strokeWidth, vectorEffect, style, className, }: SvgShapeHandleProps): react_jsx_runtime.JSX.Element;

export { B1, B2, B3, Box, type BoxProps, C1, Container, Divider, Grid, H1, H2, H3, H4, Heading, Icon, Inline, L1, ScrollArea, type Space, Stack, Surface, SvgBboxRect, type SvgBboxRectProps, SvgPointDot, type SvgPointDotProps, SvgShapeHandle, type SvgShapeHandleProps, SvgShapeLabel, type SvgShapeLabelProps, Text, type TextProps, numberOrString, space };
