import * as react_jsx_runtime from 'react/jsx-runtime';
import React__default from 'react';

declare const brandAssets: {
    readonly faviconIco: string;
    readonly faviconPng: string;
    readonly brandMark: string;
    readonly logoWordmark: string;
};
declare function BrandMark({ size, alt, src, ...props }: Omit<React__default.ImgHTMLAttributes<HTMLImageElement>, 'src' | 'alt'> & {
    size?: number;
    alt?: string;
    src?: string;
}): react_jsx_runtime.JSX.Element;
declare function BrandLogo({ width, alt, src, ...props }: Omit<React__default.ImgHTMLAttributes<HTMLImageElement>, 'src' | 'alt' | 'width'> & {
    width?: number | string;
    alt?: string;
    src?: string;
}): react_jsx_runtime.JSX.Element;

export { BrandLogo, BrandMark, brandAssets };
