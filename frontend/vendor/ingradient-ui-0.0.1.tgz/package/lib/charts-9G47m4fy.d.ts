declare const statusToneStyles: {
    readonly running: {
        readonly background: "var(--ig-color-status-running-bg)";
        readonly color: "var(--ig-color-status-running-text)";
    };
    readonly completed: {
        readonly background: "var(--ig-color-status-completed-bg)";
        readonly color: "var(--ig-color-status-completed-text)";
    };
    readonly queued: {
        readonly background: "var(--ig-color-status-queued-bg)";
        readonly color: "var(--ig-color-status-queued-text)";
    };
    readonly draft: {
        readonly background: "var(--ig-color-status-draft-bg)";
        readonly color: "var(--ig-color-status-draft-text)";
    };
    readonly failed: {
        readonly background: "var(--ig-color-status-failed-bg)";
        readonly color: "var(--ig-color-status-failed-text)";
    };
    readonly stopped: {
        readonly background: "var(--ig-color-status-stopped-bg)";
        readonly color: "var(--ig-color-status-stopped-text)";
    };
    readonly interrupted: {
        readonly background: "var(--ig-color-status-interrupted-bg)";
        readonly color: "var(--ig-color-status-interrupted-text)";
    };
    readonly warning: {
        readonly background: "var(--ig-color-status-warning-bg)";
        readonly color: "var(--ig-color-status-warning-text)";
    };
    readonly idle: {
        readonly background: "var(--ig-color-status-idle-bg)";
        readonly color: "var(--ig-color-status-idle-text)";
    };
};
type StatusTone = keyof typeof statusToneStyles;

declare const alertToneStyles: {
    readonly info: {
        readonly background: "var(--ig-color-alert-info-bg)";
        readonly border: "var(--ig-color-alert-info-border)";
        readonly color: "var(--ig-color-alert-info-text)";
    };
    readonly success: {
        readonly background: "var(--ig-color-alert-success-bg)";
        readonly border: "var(--ig-color-alert-success-border)";
        readonly color: "var(--ig-color-alert-success-text)";
    };
    readonly warning: {
        readonly background: "var(--ig-color-alert-warning-bg)";
        readonly border: "var(--ig-color-alert-warning-border)";
        readonly color: "var(--ig-color-alert-warning-text)";
    };
    readonly danger: {
        readonly background: "var(--ig-color-alert-danger-bg)";
        readonly border: "var(--ig-color-alert-danger-border)";
        readonly color: "var(--ig-color-alert-danger-text)";
    };
};

declare const chartPalette: readonly ["var(--ig-color-chart-1)", "var(--ig-color-chart-2)", "var(--ig-color-chart-3)", "var(--ig-color-chart-4)", "var(--ig-color-chart-5)", "var(--ig-color-chart-6)"];

export { type StatusTone as S, alertToneStyles as a, chartPalette as c, statusToneStyles as s };
