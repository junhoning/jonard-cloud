import * as styled_components from 'styled-components';

declare const surfacePanel: styled_components.RuleSet<object>;
declare const surfaceRaised: styled_components.RuleSet<object>;
declare const surfaceCard: styled_components.RuleSet<object>;
declare const surfaceRounded: styled_components.RuleSet<object>;

declare const controlField: styled_components.RuleSet<object>;

declare const calendarNavigation: styled_components.RuleSet<object>;
declare const calendarDayStates: styled_components.RuleSet<object>;

declare const buttonPrimary: styled_components.RuleSet<object>;
declare const buttonSecondary: styled_components.RuleSet<object>;
declare const buttonAccent: styled_components.RuleSet<object>;
declare const buttonDanger: styled_components.RuleSet<object>;
declare const buttonDangerSecondary: styled_components.RuleSet<object>;
declare const buttonGhost: styled_components.RuleSet<object>;
declare const buttonGhostDanger: styled_components.RuleSet<object>;

declare const stateTitleText: styled_components.RuleSet<object>;
declare const stateDescriptionText: styled_components.RuleSet<object>;
declare const stateCenteredLayout: styled_components.RuleSet<object>;

export { buttonDanger as a, buttonAccent as b, buttonDangerSecondary as c, buttonGhost as d, buttonGhostDanger as e, buttonPrimary as f, buttonSecondary as g, calendarDayStates as h, calendarNavigation as i, controlField as j, stateDescriptionText as k, stateTitleText as l, surfaceCard as m, surfacePanel as n, surfaceRaised as o, surfaceRounded as p, stateCenteredLayout as s };
