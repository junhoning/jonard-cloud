export { S as StatusTone, a as alertToneStyles, c as chartPalette, s as statusToneStyles } from './charts-9G47m4fy.js';
import * as react_jsx_runtime from 'react/jsx-runtime';
import * as React from 'react';
import React__default from 'react';
export { b as buttonAccent, a as buttonDanger, c as buttonDangerSecondary, d as buttonGhost, e as buttonGhostDanger, f as buttonPrimary, g as buttonSecondary, h as calendarDayStates, i as calendarNavigation, j as controlField, s as stateCenteredLayout, k as stateDescriptionText, l as stateTitleText, m as surfaceCard, n as surfacePanel, o as surfaceRaised, p as surfaceRounded } from './states-KHk94m3R.js';
import * as styled_components from 'styled-components';

declare const foundationColors: {
    readonly slate950: "#0f1115";
    readonly slate925: "#10151d";
    readonly slate900: "#111821";
    readonly slate880: "rgba(12, 15, 20, 0.88)";
    readonly slate860: "rgba(12, 15, 20, 0.8)";
    readonly slate840: "rgba(13, 18, 27, 0.92)";
    readonly white04: "rgba(255, 255, 255, 0.04)";
    readonly white06: "rgba(255, 255, 255, 0.06)";
    readonly white07: "rgba(255, 255, 255, 0.07)";
    readonly white08: "rgba(255, 255, 255, 0.08)";
    readonly white10: "rgba(255, 255, 255, 0.1)";
    readonly white12: "rgba(255, 255, 255, 0.12)";
    readonly white18: "rgba(255, 255, 255, 0.18)";
    readonly white24: "rgba(255, 255, 255, 0.24)";
    readonly blue500: "#4d88ff";
    readonly blue600: "#2962d9";
    readonly blue300: "#8cb6ff";
    readonly blueTint12: "rgba(77, 136, 255, 0.12)";
    readonly blueTint14: "rgba(77, 136, 255, 0.14)";
    readonly blueTint16: "rgba(77, 136, 255, 0.16)";
    readonly blueTint18: "rgba(77, 136, 255, 0.18)";
    readonly blueTint28: "rgba(77, 136, 255, 0.28)";
    readonly blueTint38: "rgba(91, 144, 255, 0.38)";
    readonly blueTint42: "rgba(77, 136, 255, 0.42)";
    readonly green500: "#35c6a7";
    readonly greenTint12: "rgba(43, 181, 114, 0.12)";
    readonly greenTint18: "rgba(43, 181, 114, 0.18)";
    readonly amber500: "#ffd179";
    readonly amberTint18: "rgba(251, 146, 60, 0.18)";
    readonly amberTint20: "rgba(255, 196, 61, 0.2)";
    readonly red300: "#ff9a9a";
    readonly redTint12: "rgba(239, 68, 68, 0.12)";
    readonly redTint18: "rgba(239, 68, 68, 0.18)";
    readonly cyanTint18: "rgba(56, 189, 248, 0.18)";
    readonly violet300: "#c084fc";
    readonly borderStrong: "rgba(148, 163, 184, 0.18)";
    readonly overlayBackdrop: "rgba(4, 8, 14, 0.72)";
    readonly radialA: "rgba(66, 139, 202, 0.18)";
    readonly radialB: "rgba(0, 158, 115, 0.12)";
    readonly textPrimary: "#edf2f7";
    readonly textSecondary: "#d7deea";
    readonly textMuted: "#98a2b3";
    readonly textSoft: "#7e8fa3";
    readonly textSuccess: "#9ef0c1";
    readonly textWarning: "#ffe08a";
    readonly textDanger: "#fca5a5";
    readonly textInfo: "#cfe0ff";
    readonly textSuccessSoft: "#b7f6d1";
    readonly textWarningSoft: "#ffd6a5";
    readonly textDangerSoft: "#fecaca";
    readonly textCyan: "#8fe6ff";
    readonly textBlue: "#a9c6ff";
    readonly textSlate: "#cbd5e1";
    readonly textSlateSoft: "#d5dee9";
    readonly textOrange: "#fdba74";
    readonly tagClassificationBg: "rgba(110, 200, 122, 0.15)";
    readonly tagClassificationText: "#6ec87a";
    readonly tagSegmentationBg: "rgba(180, 120, 230, 0.15)";
    readonly tagSegmentationText: "#c07be8";
    readonly tagObjectDetectionBg: "rgba(77, 136, 255, 0.15)";
    readonly syncChipSyncedBg: "rgba(34, 197, 94, 0.92)";
    readonly syncChipUploadingBg: "rgba(234, 179, 8, 0.92)";
    readonly syncChipFailedBg: "rgba(220, 38, 38, 0.92)";
    readonly syncChipLocalBg: "rgba(75, 85, 99, 0.92)";
    readonly syncChipOnText: "#ffffff";
    readonly imageGroupCircleBg: "rgba(12, 16, 24, 0.92)";
    readonly imageGroupCircleBorder: "rgba(255, 255, 255, 0.14)";
    readonly dangerDimBg: "rgba(120, 28, 28, 0.18)";
    readonly dangerDimBorder: "rgba(224, 92, 92, 0.45)";
};
declare const foundationColorsLight: {
    readonly slate950: "#ffffff";
    readonly slate925: "#f7f9fb";
    readonly slate900: "#eef2f7";
    readonly slate880: "rgba(255, 255, 255, 0.92)";
    readonly slate860: "rgba(255, 255, 255, 0.85)";
    readonly slate840: "rgba(247, 249, 251, 0.92)";
    readonly white04: "rgba(15, 18, 25, 0.04)";
    readonly white06: "rgba(15, 18, 25, 0.05)";
    readonly white07: "rgba(15, 18, 25, 0.06)";
    readonly white08: "rgba(15, 18, 25, 0.08)";
    readonly white10: "rgba(15, 18, 25, 0.09)";
    readonly white12: "rgba(15, 18, 25, 0.10)";
    readonly white18: "rgba(15, 18, 25, 0.14)";
    readonly white24: "rgba(15, 18, 25, 0.18)";
    readonly blue500: "#214bb8";
    readonly blue600: "#143fa6";
    readonly blue300: "#214bb8";
    readonly blueTint12: "rgba(58, 115, 230, 0.12)";
    readonly blueTint14: "rgba(58, 115, 230, 0.14)";
    readonly blueTint16: "rgba(58, 115, 230, 0.16)";
    readonly blueTint18: "rgba(58, 115, 230, 0.18)";
    readonly blueTint28: "rgba(58, 115, 230, 0.28)";
    readonly blueTint38: "rgba(58, 115, 230, 0.38)";
    readonly blueTint42: "rgba(58, 115, 230, 0.42)";
    readonly green500: "#1a8f6f";
    readonly greenTint12: "rgba(26, 143, 111, 0.12)";
    readonly greenTint18: "rgba(26, 143, 111, 0.18)";
    readonly amber500: "#b8761a";
    readonly amberTint18: "rgba(184, 118, 26, 0.18)";
    readonly amberTint20: "rgba(184, 118, 26, 0.2)";
    readonly red300: "#cc2929";
    readonly redTint12: "rgba(204, 41, 41, 0.12)";
    readonly redTint18: "rgba(204, 41, 41, 0.18)";
    readonly cyanTint18: "rgba(14, 116, 144, 0.18)";
    readonly violet300: "#7c3aed";
    readonly borderStrong: "rgba(15, 23, 42, 0.14)";
    readonly overlayBackdrop: "rgba(15, 23, 42, 0.32)";
    readonly radialA: "rgba(58, 115, 230, 0.10)";
    readonly radialB: "rgba(26, 143, 111, 0.07)";
    readonly textPrimary: "#0f1219";
    readonly textSecondary: "#384155";
    readonly textMuted: "#475467";
    readonly textSoft: "#5e6776";
    readonly textSuccess: "#0e5a44";
    readonly textWarning: "#7a4f10";
    readonly textDanger: "#8a1818";
    readonly textInfo: "#1f4fb8";
    readonly textSuccessSoft: "#0e5a44";
    readonly textWarningSoft: "#7a4f10";
    readonly textDangerSoft: "#8a1818";
    readonly textCyan: "#0e5b6c";
    readonly textBlue: "#1f4fb8";
    readonly textSlate: "#374151";
    readonly textSlateSoft: "#384155";
    readonly textOrange: "#7d4310";
    readonly tagClassificationBg: "rgba(34, 139, 50, 0.12)";
    readonly tagClassificationText: "#2f7a3a";
    readonly tagSegmentationBg: "rgba(120, 60, 175, 0.12)";
    readonly tagSegmentationText: "#7c3aed";
    readonly tagObjectDetectionBg: "rgba(33, 75, 184, 0.12)";
    readonly syncChipSyncedBg: "rgba(22, 163, 74, 0.92)";
    readonly syncChipUploadingBg: "rgba(202, 138, 4, 0.92)";
    readonly syncChipFailedBg: "rgba(185, 28, 28, 0.92)";
    readonly syncChipLocalBg: "rgba(75, 85, 99, 0.92)";
    readonly syncChipOnText: "#ffffff";
    readonly imageGroupCircleBg: "rgba(15, 23, 42, 0.85)";
    readonly imageGroupCircleBorder: "var(--ig-color-white-18)";
    readonly dangerDimBg: "rgba(185, 28, 28, 0.10)";
    readonly dangerDimBorder: "rgba(185, 28, 28, 0.40)";
};

declare const opacityScale: {
    readonly svgFillFaint: 0.07;
    readonly svgFillSubtle: 0.13;
    readonly svgFillSoft: 0.15;
    readonly svgFillMedium: 0.22;
    readonly ghost: 0.35;
    readonly faded: 0.4;
    readonly disabled: 0.5;
    readonly overlay: 0.55;
    readonly muted: 0.6;
    readonly subtle: 0.7;
    readonly emphatic: 0.8;
    readonly loud: 0.85;
    readonly loudPlus: 0.86;
    readonly prominent: 0.88;
    readonly near: 0.9;
};

declare const effectsScale: {
    readonly blur2xs: "blur(1px)";
    readonly blurXs: "blur(8px)";
    readonly blurSm: "blur(14px)";
    readonly blurMd: "blur(16px)";
    readonly blurLg: "blur(10px)";
    readonly blurXl: "blur(12px)";
};

declare const iconSizes: {
    readonly sub: "8px";
    readonly '2xs': "11px";
    readonly xs: "12px";
    readonly xsPlus: "13px";
    readonly sm: "14px";
    readonly smPlus: "15px";
    readonly md: "16px";
    readonly lg: "18px";
    readonly xl: "20px";
    readonly '2xl': "22px";
    readonly '3xl': "24px";
};
declare const iconSizeNumbers: {
    readonly '2xs': 11;
    readonly xs: 12;
    readonly xsPlus: 13;
    readonly sm: 14;
    readonly smPlus: 15;
    readonly md: 16;
    readonly lg: 18;
    readonly xl: 20;
    readonly '2xl': 22;
    readonly '3xl': 24;
};
declare const svgStrokeWidths: {
    readonly thin: 1.3;
    readonly mid: 1.8;
    readonly regular: 2;
    readonly midBold: 2.4;
    readonly bold: 2.5;
};

declare const popupSizes: {
    readonly '3xs': "80px";
    readonly '3xsPlus': "96px";
    readonly '3xsWide': "104px";
    readonly '2xsNarrowTight': "116px";
    readonly '2xsNarrow': "120px";
    readonly '2xsTight': "124px";
    readonly '2xs': "140px";
    readonly '2xsPlus': "160px";
    readonly xsNarrow: "190px";
    readonly listMin: "200px";
    readonly xsTight: "210px";
    readonly xs: "220px";
    readonly xsPlus: "240px";
    readonly smNarrow: "260px";
    readonly sm: "280px";
    readonly mdNarrow: "300px";
    readonly md: "320px";
    readonly lg: "360px";
    readonly filterPanel: "380px";
    readonly xl: "480px";
    readonly '2xlNarrow': "420px";
    readonly lgPlus: "440px";
    readonly '2xl': "560px";
    readonly '3xl': "920px";
    readonly '2xlWide': "520px";
    readonly '3xlNarrow': "640px";
    readonly '3xlMid': "720px";
    readonly '3xlWide': "820px";
    readonly '4xlNarrow': "960px";
    readonly '4xlMid': "1120px";
    readonly '4xl': "1200px";
};
declare const popupSizeNumbers: {
    readonly '3xs': 80;
    readonly '3xsPlus': 96;
    readonly '3xsWide': 104;
    readonly '2xsNarrowTight': 116;
    readonly '2xsNarrow': 120;
    readonly '2xsTight': 124;
    readonly '2xs': 140;
    readonly '2xsPlus': 160;
    readonly xsNarrow: 190;
    readonly listMin: 200;
    readonly xsTight: 210;
    readonly xs: 220;
    readonly xsPlus: 240;
    readonly smNarrow: 260;
    readonly sm: 280;
    readonly mdNarrow: 300;
    readonly md: 320;
    readonly lg: 360;
    readonly filterPanel: 380;
    readonly xl: 480;
    readonly '2xlNarrow': 420;
    readonly lgPlus: 440;
    readonly '2xl': 560;
    readonly '2xlWide': 520;
    readonly '3xlNarrow': 640;
    readonly '3xlMid': 720;
    readonly '3xlWide': 820;
    readonly '3xl': 920;
    readonly '4xlNarrow': 960;
    readonly '4xlMid': 1120;
    readonly '4xl': 1200;
};

declare const layoutScale: {
    readonly pageMaxWidth: "1280px";
    readonly topbarHeight: "80px";
    readonly sidebarHeader: "72px";
    readonly sidebarCollapse: "100px";
    readonly panelMinHeight: "300px";
    readonly loadingPanelHeight: "180px";
    readonly shadowYOffset: "40px";
    readonly shadowBlur: "80px";
    readonly formLabelCol: "140px";
    readonly formLabelColWide: "160px";
    readonly captureBar: "100px";
    readonly captureGrid: "100px";
    readonly histogramWidth: "224px";
    readonly histogramHeight: "84px";
    readonly datasetCardMinHeight: "112px";
    readonly datasetCardRecentMinHeight: "108px";
    readonly logTimeMin: "45px";
    readonly logDetailLeft: "254px";
    readonly logDetailTop: "58px";
    readonly logDetailWidth: "272px";
    readonly colorPlaneHeight: "120px";
    readonly colorThumbSize: "18px";
};

declare const spacingScale: {
    readonly 0: "0px";
    readonly '1px': "1px";
    readonly '2px': "2px";
    readonly '3px': "3px";
    readonly '-1px': "-1px";
    readonly '-2px': "-2px";
    readonly hoverLiftY: "-1px";
    readonly 1: "4px";
    readonly '1Plus': "5px";
    readonly 2: "6px";
    readonly '2Plus': "7px";
    readonly 3: "8px";
    readonly 4: "10px";
    readonly 5: "12px";
    readonly 6: "14px";
    readonly 7: "16px";
    readonly 8: "18px";
    readonly 9: "20px";
    readonly 10: "22px";
    readonly 11: "24px";
    readonly 12: "28px";
    readonly 13: "32px";
};

declare const borderWidthScale: {
    readonly '1px': "1px";
    readonly '2px': "2px";
    readonly '3px': "3px";
};

declare const radiusScale: {
    readonly '2xs': "6px";
    readonly xxs: "8px";
    readonly xs: "10px";
    readonly sm: "12px";
    readonly md: "14px";
    readonly lg: "16px";
    readonly xl: "18px";
    readonly '2xl': "20px";
    readonly '4xl': "24px";
    readonly pill: "999px";
};

declare const typographyScale: {
    readonly fontSans: "\"IBM Plex Sans\", \"Segoe UI\", sans-serif";
    readonly fontMono: "\"IBM Plex Mono\", \"SFMono-Regular\", Consolas, monospace";
    readonly size3xs: "10px";
    readonly size2xs: "11px";
    readonly sizeXs: "12px";
    readonly sizeSm: "13px";
    readonly sizeMd: "14px";
    readonly sizeLg: "15px";
    readonly sizeXl: "16px";
    readonly size2xl: "18px";
    readonly size3xl: "20px";
    readonly size3xlPlus: "22px";
    readonly size4xl: "24px";
    readonly size5xl: "28px";
    readonly weightRegular: 400;
    readonly weightMedium: 500;
    readonly weightSemibold: 600;
    readonly weightBold: 700;
    readonly weightBlack: 800;
    readonly letterSpacingHeading: "-0.02em";
    readonly letterSpacingMicro: "0.01em";
    readonly letterSpacingTight: "0.03em";
    readonly letterSpacingNormal: "0.04em";
    readonly letterSpacingWide: "0.05em";
    readonly letterSpacingWider: "0.06em";
    readonly letterSpacingWidest: "0.08em";
    readonly lineHeightNone: 1;
    readonly lineHeightTight: 1.35;
    readonly lineHeightSnug: 1.4;
    readonly lineHeightBase: 1.45;
    readonly lineHeightRelaxed: 1.5;
    readonly lineHeightRelaxedPlus: 1.55;
    readonly lineHeightLoose: 1.6;
    readonly textClampNarrow: "5.5em";
    readonly textClampMid: "8em";
    readonly svgTspanDyPrimary: "-0.2em";
    readonly svgTspanDySecondary: "1.2em";
};

declare const shadowScale: {
    readonly panel: "0 20px 60px rgba(0, 0, 0, 0.25)";
    readonly floating: "0 30px 80px var(--ig-color-overlay-dim)";
    readonly popover: "0 24px 60px var(--ig-color-blue-tint-34), inset 0 1px 0 rgba(255, 255, 255, 0.05)";
    readonly menu: "0 20px 40px rgba(0, 0, 0, 0.35)";
    readonly hoverLift: "0 12px 24px var(--ig-color-blue-strong-tint-24)";
    readonly focusRing: "0 0 0 3px var(--ig-color-blue-tint-16)";
    readonly drawerLift: "0 16px 48px rgba(4, 8, 14, 0.72)";
    readonly dangerHoverLift: "0 10px 28px rgba(127, 29, 29, 0.32)";
    readonly controlElevated: "inset 0 1px 0 rgba(255, 255, 255, 0.05), 0 10px 24px rgba(0, 0, 0, 0.12)";
};
declare const shadowScaleLight: {
    readonly panel: "0 16px 40px rgba(15, 23, 42, 0.08)";
    readonly floating: "0 24px 60px rgba(15, 23, 42, 0.14)";
    readonly popover: "0 20px 48px rgba(15, 23, 42, 0.12)";
    readonly menu: "0 16px 32px rgba(15, 23, 42, 0.10)";
    readonly hoverLift: "0 12px 24px rgba(58, 115, 230, 0.16)";
    readonly focusRing: "0 0 0 3px rgba(58, 115, 230, 0.20)";
    readonly drawerLift: "0 16px 48px rgba(15, 23, 42, 0.32)";
    readonly dangerHoverLift: "0 10px 28px rgba(185, 28, 28, 0.20)";
    readonly controlElevated: "0 10px 24px rgba(15, 23, 42, 0.08)";
};

declare const rotations: {
    readonly zero: "0deg";
    readonly half: "180deg";
    readonly full: "360deg";
};
declare const gradientAngles: {
    readonly horizontal: "90deg";
    readonly diagonal: "135deg";
};
declare const motionScale: {
    readonly fastest: "0.12s";
    readonly swift: "0.15s";
    readonly fast: "0.16s ease";
    readonly fastEase: "0.16s ease";
    readonly normal: "0.24s ease";
    readonly normalEase: "0.2s ease";
    readonly mobileNav: "0.28s cubic-bezier(0.4, 0, 0.2, 1)";
    readonly spinner: "0.7s";
    readonly spinnerFast: "0.75s";
    readonly spinnerSlow: "0.8s";
    readonly shimmer: "1s";
    readonly progressBar: "1.2s";
    readonly skeleton: "1.3s";
    readonly syncSpin: "1.5s";
};

declare const breakpoints: {
    readonly sm: 640;
    readonly smPlus: 720;
    readonly md: 768;
    readonly lg: 1024;
    readonly xl: 1280;
};
declare const media: {
    readonly sm: "@media (max-width: 640px)";
    readonly smPlus: "@media (max-width: 720px)";
    readonly md: "@media (max-width: 768px)";
    readonly lg: "@media (max-width: 1024px)";
    readonly xl: "@media (max-width: 1280px)";
};

declare const zIndexScale: {
    readonly hidden: 0;
    readonly base: 1;
    readonly raised: 2;
    readonly raisedPlus: 3;
    readonly captureHigh: 4;
    readonly capture: 5;
    readonly captureSuper: 6;
    readonly captureTop: 7;
    readonly sticky: 10;
    readonly stickyPlus: 20;
    readonly stickyTop: 30;
    readonly header: 20;
    readonly overlay: 24;
    readonly overlayLow: 50;
    readonly dotMenu: 200;
    readonly dotMenuPlus: 201;
    readonly dropdown: 100;
    readonly mobileNavBackdrop: 110;
    readonly mobileNav: 120;
    readonly mobileMenu: 200;
    readonly popover: 500;
    readonly contextMenu: 1000;
    readonly drawer: 1100;
    readonly modal: 1200;
    readonly topbar: 9998;
    readonly toast: 9000;
    readonly tooltip: 9999;
};

declare const controlSizes: {
    readonly xs: "28px";
    readonly xsPlus: "30px";
    readonly sm: "32px";
    readonly smPlus: "34px";
    readonly md: "36px";
    readonly midPlus: "40px";
    readonly midPlusTall: "60px";
    readonly '2xlWide': "56px";
    readonly lg: "44px";
    readonly xl: "48px";
    readonly '2xl': "52px";
    readonly '3xl': "60px";
    readonly '3xlPlus': "64px";
};
declare const controlSizeNumbers: {
    readonly xs: 28;
    readonly xsPlus: 30;
    readonly sm: 32;
    readonly smPlus: 34;
    readonly md: 36;
    readonly midPlus: 40;
    readonly midPlusTall: 60;
    readonly '2xlWide': 56;
    readonly lg: 44;
    readonly xl: 48;
    readonly '2xl': 52;
    readonly '3xl': 60;
    readonly '3xlPlus': 64;
};

declare const chartColors: {
    readonly blue: "#60a5fa";
    readonly purple: "#a78bfa";
    readonly green: "#34d399";
    readonly cyan: "#22d3ee";
    readonly neutral: "#94a3b8";
    readonly gold: "#facc15";
    readonly violet: "#6c5ce7";
    readonly teal: "#00b894";
    readonly amber: "#fdcb6e";
    readonly tickColor: "#9ca3af";
    readonly tagClassification: "#6ec87a";
    readonly tagSegmentation: "#c07be8";
    readonly coral: "#e17055";
    readonly lightBlue: "#74b9ff";
    readonly lightViolet: "#a29bfe";
    readonly mint: "#55efc4";
    readonly canvasExportBg: "#181818";
    readonly white: "#ffffff";
};

declare const chartHeights: {
    readonly sm: 200;
    readonly smPlus: 220;
    readonly md: 240;
    readonly lg: 260;
    readonly xl: 280;
    readonly xlPlus: 304;
    readonly '2xl': 308;
    readonly '3xl': 320;
};

declare const transformScale: {
    readonly press: 0.95;
    readonly drag: 0.985;
    readonly hoverLift: 1.04;
};
declare const aspectRatios: {
    readonly landscape: "4 / 3";
};

interface IngradientTheme {
    name: string;
    colors: {
        bgCanvas: string;
        bgCanvasAlt: string;
        bgRadialA: string;
        bgRadialB: string;
        surfaceHeader: string;
        surfacePanel: string;
        surfaceRaised: string;
        surfaceMuted: string;
        surfaceInteractive: string;
        surfaceActive: string;
        borderSubtle: string;
        borderStrong: string;
        textPrimary: string;
        textSecondary: string;
        textMuted: string;
        textSoft: string;
        accent: string;
        accentStrong: string;
        accentSoft: string;
        success: string;
        warning: string;
        danger: string;
    };
    radius: {
        sm: string;
        md: string;
        lg: string;
        xl: string;
        pill: string;
    };
    shadows: {
        panel: string;
        floating: string;
    };
    breakpoints: {
        sm: number;
        md: number;
        lg: number;
        xl: number;
    };
    motion: {
        fast: string;
        normal: string;
    };
    typography: {
        fontSans: string;
        fontMono: string;
    };
}

declare const ingradientThemeDark: IngradientTheme;

declare const ingradientThemeLight: IngradientTheme;

declare const ingradientTheme: IngradientTheme;
declare const themes: {
    dark: IngradientTheme;
    light: IngradientTheme;
    portalDark: IngradientTheme;
    portalLight: IngradientTheme;
};
type ThemeMode = 'dark' | 'light';

/**
 * 카테고리 단위 토큰 override container. CSS 변수 key/value pair.
 *
 * 동일 shape 를 themes/ , brands/ 도 사용 (개념 일치).
 */
interface TokenCategory {
    cssVars: Record<string, string>;
}

/**
 * industrial-dark — platform / edge 기본 분위기. 현재 dark mode 와 동일 (override 없음).
 */
declare const industrialDarkTheme: TokenCategory;

/**
 * medical-dark — 의료 영상 라벨링 분위기. canvas 를 약간 더 어둡게 (영상 contrast 우선).
 */
declare const medicalDarkTheme: TokenCategory;

declare const themeRegistry: Record<string, TokenCategory>;

/**
 * default brand — Ingradient 기본. accent color override 없음.
 */
declare const defaultBrand: TokenCategory;

/**
 * finemtech brand — orange accent.
 */
declare const finemtechBrand: TokenCategory;

/**
 * samsung brand — blue accent (강화).
 */
declare const samsungBrand: TokenCategory;

declare const brandRegistry: Record<string, TokenCategory>;

/**
 * comfortable — 현재 default control sizes 유지. medical (의료 라벨링) 의 기본 밀도.
 */
declare const comfortableDensity: TokenCategory;

/**
 * compact — tight controls, reduced control heights.
 * platform / edge 의 기본 밀도.
 */
declare const compactDensity: TokenCategory;

/**
 * ultra-dense — 최대 밀도 (대시보드, 데이터 격자 등). compact 보다 추가 축소.
 */
declare const ultraDenseDensity: TokenCategory;

declare const densityRegistry: Record<string, TokenCategory>;

/**
 * Service identifier — 어느 제품의 preset 인지.
 */
type PresetService = 'platform' | 'edge' | 'medical';
/**
 * 분위기 단위 토큰 set 의 id. Phase 4 이후 themes/ 에 실제 값 채워질 때 확장.
 */
type ThemeId = 'industrial-dark' | 'industrial-light' | 'medical' | 'medical-dark' | 'light' | 'dark';
/**
 * 고객사 / 브랜드 id. Phase 4 이후 brands/ 채워질 때 확장.
 */
type BrandId = 'default' | 'finemtech' | 'samsung';
/**
 * 정보 밀도 id. Phase 4 이후 density/ 채워질 때 실제 토큰 적용.
 */
type DensityId = 'comfortable' | 'compact' | 'ultra-dense';
/**
 * 토큰 부분 override — 특정 preset 만의 미세 조정용.
 * 현재는 빈 type, 사용 시 `Partial<IngradientTheme>` 또는 CSS 변수 맵으로 확장.
 */
type TokenOverrides = Record<string, string>;
/**
 * 하나의 완성된 제품 디자인 snapshot. Theme + Brand + Density + Mode 조합 + optional override.
 *
 * 상위 문서: docs-legacy/storybook_architecture_restructure.md § 4
 */
interface Preset {
    /** unique id (e.g. 'platform-0.0.1') */
    id: string;
    service: PresetService;
    /** semver 또는 임의 버전 문자열 */
    version: string;
    theme: ThemeId;
    brand: BrandId;
    density: DensityId;
    mode: ThemeMode;
    /** 추가 토큰 override (optional) */
    overrides?: TokenOverrides;
}
/**
 * composePreset() 결과 — 런타임에 적용할 값들.
 */
interface ComposedPreset {
    /** 현재 ThemeProvider 가 받는 mode (Phase 4 에서는 preset.mode 직통) */
    mode: ThemeMode;
    /** data-ig-* attr 로 DOM 에 표현 — CSS 선택자로 density/brand 별 override 가능 */
    attributes: Record<string, string>;
    /** 적용된 추가 CSS 변수 override (preset.overrides + 카테고리 합성) */
    cssVariables: Record<string, string>;
    /** preset 원본 (메타데이터 접근용) */
    source: Preset;
}

/**
 * Preset 을 런타임 적용 가능한 형태로 합성.
 *
 * 합성 순서 (뒤가 앞을 override):
 *   theme → brand → density → preset.overrides
 *
 * mode (light/dark) 는 ThemeProvider 가 별도로 처리하므로 cssVariables 에 포함 안 함.
 */
declare function composePreset(preset: Preset): ComposedPreset;

interface PresetProviderProps {
    /** 적용할 preset. 미지정 시 PresetProvider 가 thin pass-through (mode='dark' default). */
    preset?: Preset;
    /** preset.mode 를 무시하고 강제 mode. Global toolbar 의 Mode selector 용. */
    modeOverride?: ThemeMode;
    /** preset.density 위에 추가 density 적용. Global toolbar 의 Density selector 용. */
    densityOverride?: DensityId;
    children: React__default.ReactNode;
}
/**
 * Preset 을 런타임에 적용한다. 내부에서 `IngradientThemeProvider` 를 감싸므로
 * 별도로 ThemeProvider 를 둘 필요 없음.
 *
 * Override 우선순위 (뒤가 앞을 이김):
 *   composePreset(preset).cssVariables → densityRegistry[densityOverride].cssVars
 *   composePreset(preset).mode → modeOverride
 */
declare function PresetProvider({ preset, modeOverride, densityOverride, children }: PresetProviderProps): react_jsx_runtime.JSX.Element;
/**
 * 현재 적용된 preset (없으면 null). 메타데이터 접근용.
 */
declare function usePreset(): ComposedPreset | null;

/**
 * platform 0.0.1 — MVP UI snapshot.
 *
 * 상위 문서 § 4.2 의 platform/0.0.1 정의:
 *   - 초기 MVP UI
 *   - compact density
 *   - industrial-dark 기반
 *   - 기본 sidebar 구조
 */
declare const platformV001: Preset;

/**
 * edge 0.0.1 — Electron 캡처/라벨링 데스크톱 앱.
 *
 * 인벤토리 결과 (docs-legacy/plan/storybook-restructure-phase-6-inventory.md § 1):
 *   - Electron 앱, dark 배경, compact 밀도
 *   - @ingradient/ui 적극 사용 중
 */
declare const edgeV001: Preset;

/**
 * medical 0.0.1 — 의료 영상 라벨링 웹 앱 (medilabel).
 *
 * 인벤토리 결과 (docs-legacy/plan/storybook-restructure-phase-6-inventory.md § 2):
 *   - dark mode (DICOM 영상 관찰 — 눈 피로 최소화)
 *   - comfortable density (웹, 읽기성)
 *   - medilabel 은 @ingradient/ui 미사용 → 시각 재현 mockup
 */
declare const medicalV001: Preset;

declare const appShell: styled_components.RuleSet<object>;
declare const headerSurface: styled_components.RuleSet<object>;
declare const pageHeaderSurface: styled_components.RuleSet<object>;
declare const pageContentLayout: styled_components.RuleSet<object>;

/**
 * @deprecated --portal-* 레거시 CSS 변수 매핑.
 *
 * 2026-05-08 기준 ingradient-platform, ingradient-edge, @ingradient/ui 자체
 * 어디서도 var(--portal-*) 를 사용하지 않음 (D-5 마이그레이션 완료).
 *
 * 이 매핑은 더 이상 renderTokensCss() 출력에 포함되지 않으며, 외부 코드가
 * 이 export를 import해서 직접 emit하지 않는 한 런타임에 적용되지 않음.
 *
 * 다음 메이저 버전에서 파일 자체 삭제 예정. 새 코드는 var(--ig-color-*) 사용.
 */
declare const legacyPortalCssVariables: {
    readonly '--portal-bg-base': "var(--ig-color-bg-canvas)";
    readonly '--portal-bg-radial-a': "var(--ig-color-bg-radial-a)";
    readonly '--portal-bg-radial-b': "var(--ig-color-bg-radial-b)";
    readonly '--portal-surface-header': "var(--ig-color-surface-header)";
    readonly '--portal-surface-panel': "var(--ig-color-surface-panel)";
    readonly '--portal-surface-elevated': "var(--ig-color-surface-raised)";
    readonly '--portal-surface-muted': "var(--ig-color-surface-muted)";
    readonly '--portal-surface-interactive': "var(--ig-color-surface-interactive)";
    readonly '--portal-surface-active': "var(--ig-color-surface-active)";
    readonly '--portal-border': "var(--ig-color-border-subtle)";
    readonly '--portal-border-strong': "var(--ig-color-border-strong)";
    readonly '--portal-text-primary': "var(--ig-color-text-primary)";
    readonly '--portal-text-secondary': "var(--ig-color-text-secondary)";
    readonly '--portal-text-muted': "var(--ig-color-text-muted)";
    readonly '--portal-text-soft': "var(--ig-color-text-soft)";
    readonly '--portal-accent': "var(--ig-color-accent)";
    readonly '--portal-accent-strong': "var(--ig-color-accent-strong)";
    readonly '--portal-accent-soft': "var(--ig-color-accent-soft)";
    readonly '--portal-success': "var(--ig-color-success)";
    readonly '--portal-warning': "var(--ig-color-warning)";
    readonly '--portal-danger': "var(--ig-color-danger)";
    readonly '--portal-shadow': "var(--ig-shadow-panel)";
    readonly '--portal-scrollbar-thumb': "var(--ig-scrollbar-thumb)";
    readonly '--portal-scrollbar-thumb-hover': "var(--ig-scrollbar-thumb-hover)";
    readonly '--portal-scrollbar-thumb-active': "var(--ig-scrollbar-thumb-active)";
};

declare function buildTokenCssVariables(mode?: 'dark' | 'light'): {
    '--ig-color-bg-canvas': string;
    '--ig-color-bg-radial-a': string;
    '--ig-color-bg-radial-b': string;
    '--ig-color-surface-header': string;
    '--ig-color-surface-panel': string;
    '--ig-color-surface-raised': string;
    '--ig-color-surface-muted': string;
    '--ig-color-surface-interactive': string;
    '--ig-color-surface-active': string;
    '--ig-color-border-subtle': string;
    '--ig-color-border-strong': string;
    '--ig-color-text-primary': string;
    '--ig-color-text-secondary': string;
    '--ig-color-text-muted': string;
    '--ig-color-text-soft': string;
    '--ig-color-state-title': string;
    '--ig-color-state-description': string;
    '--ig-color-accent': string;
    '--ig-color-accent-strong': string;
    '--ig-color-accent-soft': string;
    '--ig-color-success': string;
    '--ig-color-warning': string;
    '--ig-color-danger': string;
    '--ig-color-surface-card-a': "rgba(255, 255, 255, 0.96)" | "rgba(18, 21, 28, 0.96)";
    '--ig-color-surface-card-b': "rgba(247, 249, 251, 0.96)" | "rgba(10, 14, 20, 0.96)";
    '--ig-color-surface-interactive-hover': string;
    '--ig-color-surface-focus': "rgba(255, 255, 255, 0.98)" | "rgba(16, 22, 32, 0.98)";
    '--ig-color-accent-ring': "rgba(58, 115, 230, 0.55)" | "rgba(91, 144, 255, 0.7)";
    '--ig-color-accent-border-strong': string;
    '--ig-color-accent-soft-surface': string;
    '--ig-color-accent-soft-surface-hover': string;
    '--ig-color-on-accent': "#ffffff";
    '--ig-shadow-panel': string;
    '--ig-shadow-floating': string;
    '--ig-shadow-popover': string;
    '--ig-shadow-menu': string;
    '--ig-shadow-hover-lift': string;
    '--ig-shadow-focus-ring': string;
    '--ig-shadow-drawer-lift': string;
    '--ig-shadow-danger-hover-lift': string;
    '--ig-shadow-control-elevated': string;
    '--ig-scrollbar-thumb': "rgba(15, 23, 42, 0.18)" | "rgba(148, 163, 184, 0.22)";
    '--ig-scrollbar-thumb-hover': "rgba(15, 23, 42, 0.28)" | "rgba(148, 163, 184, 0.34)";
    '--ig-scrollbar-thumb-active': "rgba(15, 23, 42, 0.36)" | "rgba(148, 163, 184, 0.42)";
    '--ig-color-status-running-bg': string;
    '--ig-color-status-running-text': string;
    '--ig-color-status-completed-bg': string;
    '--ig-color-status-completed-text': string;
    '--ig-color-status-queued-bg': string;
    '--ig-color-status-queued-text': string;
    '--ig-color-status-draft-bg': string;
    '--ig-color-status-draft-text': string;
    '--ig-color-status-failed-bg': string;
    '--ig-color-status-failed-text': string;
    '--ig-color-status-stopped-bg': "rgba(15, 23, 42, 0.10)" | "rgba(148, 163, 184, 0.16)";
    '--ig-color-status-stopped-text': string;
    '--ig-color-status-interrupted-bg': string;
    '--ig-color-status-interrupted-text': string;
    '--ig-color-status-warning-bg': string;
    '--ig-color-status-warning-text': string;
    '--ig-color-status-idle-bg': "rgba(15, 23, 42, 0.10)" | "rgba(67, 76, 94, 0.22)";
    '--ig-color-status-idle-text': string;
    '--ig-color-alert-info-bg': string;
    '--ig-color-alert-info-border': "rgba(58, 115, 230, 0.32)" | "rgba(77, 136, 255, 0.26)";
    '--ig-color-alert-info-text': string;
    '--ig-color-alert-success-bg': string;
    '--ig-color-alert-success-border': "rgba(26, 143, 111, 0.32)" | "rgba(43, 181, 114, 0.26)";
    '--ig-color-alert-success-text': string;
    '--ig-color-alert-warning-bg': "rgba(184, 118, 26, 0.12)" | "rgba(251, 146, 60, 0.12)";
    '--ig-color-alert-warning-border': "rgba(184, 118, 26, 0.32)" | "rgba(251, 146, 60, 0.26)";
    '--ig-color-alert-warning-text': string;
    '--ig-color-alert-danger-bg': string;
    '--ig-color-alert-danger-border': "rgba(204, 41, 41, 0.32)" | "rgba(239, 68, 68, 0.26)";
    '--ig-color-alert-danger-text': string;
    '--ig-color-chart-1': string;
    '--ig-color-chart-2': string;
    '--ig-color-chart-3': string;
    '--ig-color-chart-4': string;
    '--ig-color-chart-5': string;
    '--ig-color-chart-6': string;
    '--ig-color-chart-grid': "rgba(15, 23, 42, 0.08)" | "var(--ig-color-white-08)";
    '--ig-color-chart-separator': "rgba(255, 255, 255, 0.82)" | "rgba(10, 14, 20, 0.62)";
    '--ig-color-badge-neutral': string;
    '--ig-color-badge-accent': string;
    '--ig-color-badge-success': string;
    '--ig-color-badge-warning': string;
    '--ig-color-badge-danger': string;
    '--ig-color-tag-classification-bg': string;
    '--ig-color-tag-classification-text': string;
    '--ig-color-tag-segmentation-bg': string;
    '--ig-color-tag-segmentation-text': string;
    '--ig-color-tag-object-detection-bg': string;
    '--ig-color-sync-chip-synced-bg': string;
    '--ig-color-sync-chip-uploading-bg': string;
    '--ig-color-sync-chip-failed-bg': string;
    '--ig-color-sync-chip-local-bg': string;
    '--ig-color-sync-chip-on-text': string;
    '--ig-color-image-option-bg': "rgba(0, 0, 0, 0.5)" | "rgba(0, 0, 0, 0.6)";
    '--ig-color-image-option-bg-hover': "rgba(0, 0, 0, 0.7)" | "rgba(0, 0, 0, 0.8)";
    '--ig-color-image-group-circle-bg': string;
    '--ig-color-image-group-circle-border': string;
    '--ig-color-danger-dim-bg': string;
    '--ig-color-danger-dim-border': string;
    '--ig-color-progress-track': string;
    '--ig-color-skeleton-start': string;
    '--ig-color-skeleton-mid': string;
    '--ig-color-image-card-hover-border': string;
    '--ig-color-image-card-selected-border': string;
    '--ig-color-image-card-selected-ring': string;
    '--ig-color-image-card-gradient-a': string;
    '--ig-color-image-card-gradient-b': string;
    '--ig-color-avatar-bg': string;
    '--ig-color-selection-bg': string;
    '--ig-color-focus-bg-soft': string;
    '--ig-color-active-bg': string;
    '--ig-color-danger-bg-soft': "rgba(220, 38, 38, 0.10)" | "rgba(239, 68, 68, 0.08)";
    '--ig-color-danger-bg': "rgba(239, 68, 68, 0.12)" | "rgba(220, 38, 38, 0.14)";
    '--ig-color-danger-bg-hover': "rgba(239, 68, 68, 0.18)" | "rgba(220, 38, 38, 0.20)";
    '--ig-color-danger-bg-strong': "rgba(220, 38, 38, 0.6)" | "rgba(239, 68, 68, 0.6)";
    '--ig-color-danger-overlay': "rgba(220, 38, 38, 0.92)" | "rgba(239, 68, 68, 0.92)";
    '--ig-color-danger-overlay-hover': "rgba(185, 28, 28, 0.96)" | "rgba(220, 38, 38, 0.96)";
    '--ig-color-danger-button-bg': "rgba(220, 38, 60, 0.20)" | "rgba(255, 95, 122, 0.18)";
    '--ig-color-danger-button-border': "rgba(220, 38, 60, 0.30)" | "rgba(255, 95, 122, 0.28)";
    '--ig-color-success-bg-soft': "rgba(22, 163, 74, 0.10)" | "rgba(43, 181, 114, 0.08)";
    '--ig-color-success-bg': "rgba(22, 163, 74, 0.18)" | "rgba(60, 210, 120, 0.15)";
    '--ig-color-warning-bg': "rgba(217, 119, 6, 0.18)" | "rgba(255, 180, 60, 0.15)";
    '--ig-color-dropdown-open-shadow': "0 0 0 3px rgba(58, 115, 230, 0.20), 0 18px 36px rgba(15, 23, 42, 0.10)" | "0 0 0 3px var(--ig-color-blue-tint-16), 0 18px 36px rgba(0, 0, 0, 0.18)";
    '--ig-color-dropdown-menu-a': "rgba(255, 255, 255, 0.98)" | "rgba(18, 24, 34, 0.98)";
    '--ig-color-dropdown-menu-b': "rgba(247, 249, 251, 0.98)" | "rgba(10, 14, 20, 0.98)";
    '--ig-color-dropdown-option-hover': string;
    '--ig-color-toggle-on-bg': "rgba(58, 115, 230, 0.5)" | "rgba(77, 136, 255, 0.4)";
    '--ig-color-toggle-on-border': "rgba(58, 115, 230, 0.65)" | "rgba(77, 136, 255, 0.55)";
    '--ig-color-toggle-off-bg': string;
    '--ig-color-toggle-off-border': string;
    '--ig-color-tab-surface': string;
    '--ig-color-tab-highlight': string;
    '--ig-color-toolbar-surface': "rgba(247, 249, 251, 0.84)" | "rgba(8, 12, 18, 0.84)";
    '--ig-color-modal-backdrop': string;
    '--ig-color-overlay-dim': "rgba(0, 0, 0, 0.45)";
    '--ig-color-overlay-mid': "rgba(0, 0, 0, 0.5)";
    '--ig-color-overlay-strong': "rgba(0, 0, 0, 0.55)";
    '--ig-color-lightbox-backdrop': "rgba(0, 0, 0, 0.85)";
    '--ig-color-lightbox-surface': "rgba(255, 255, 255, 0.7)" | "rgba(7, 10, 20, 0.7)";
    '--ig-color-sidebar-bg-top': "rgba(247, 249, 251, 0.96)" | "rgba(12, 15, 20, 0.96)";
    '--ig-color-sidebar-bg-bottom': "rgba(241, 245, 249, 0.94)" | "rgba(10, 14, 20, 0.94)";
    '--ig-color-surface-dropdown-mobile-top': "rgba(255, 255, 255, 0.98)" | "rgba(18, 24, 34, 0.98)";
    '--ig-color-surface-dropdown-mobile-bottom': "rgba(247, 249, 251, 0.98)" | "rgba(10, 14, 20, 0.98)";
    '--ig-color-surface-calendar-top': "rgba(255, 255, 255, 0.96)" | "rgba(17, 23, 32, 0.96)";
    '--ig-color-surface-calendar-bottom': "rgba(247, 249, 251, 0.96)" | "rgba(10, 14, 20, 0.96)";
    '--ig-color-danger-soft-surface': "rgba(220, 38, 38, 0.12)" | "rgba(164, 44, 44, 0.22)";
    '--ig-color-danger-button-gradient-mid': "#a23030" | "#7f1d1d";
    '--ig-color-danger-button-gradient-end': "#b13838" | "#8f2f2f";
    '--ig-color-danger-button-text': "#ffffff" | "#fff4f4";
    '--ig-color-danger-button-text-strong': "#ffffff" | "#ffe1e1";
    '--ig-color-svg-stroke-on-overlay': "#ffffff";
    '--ig-color-pie-slice-label': "#0f1219" | "#eef4ff";
    '--ig-color-annotation-outline-dark': "var(--ig-color-image-option-bg)";
    '--ig-color-annotation-outline-light': "rgba(255, 255, 255, 0.9)";
    '--ig-color-white-04': string;
    '--ig-color-white-06': string;
    '--ig-color-white-07': string;
    '--ig-color-white-08': string;
    '--ig-color-white-10': string;
    '--ig-color-white-12': string;
    '--ig-color-white-18': string;
    '--ig-color-white-20': "rgba(15, 18, 25, 0.16)" | "rgba(255, 255, 255, 0.2)";
    '--ig-color-white-24': string;
    '--ig-color-white-30': "rgba(15, 18, 25, 0.22)" | "rgba(255, 255, 255, 0.3)";
    '--ig-color-white-40': "rgba(15, 18, 25, 0.32)" | "rgba(255, 255, 255, 0.4)";
    '--ig-color-white-70': "rgba(255, 255, 255, 0.7)" | "rgba(15, 18, 25, 0.62)";
    '--ig-color-white-90': "rgba(255, 255, 255, 0.9)" | "rgba(15, 18, 25, 0.82)";
    '--ig-color-white-96': "rgba(255, 255, 255, 0.96)" | "rgba(15, 18, 25, 0.88)";
    '--ig-color-inset-highlight': "rgba(15, 18, 25, 0.05)" | "rgba(255, 255, 255, 0.05)";
    '--ig-color-slate-tint-18': string;
    '--ig-color-blue-tint-06': "rgba(58, 115, 230, 0.06)" | "rgba(77, 136, 255, 0.06)";
    '--ig-color-blue-tint-08': "rgba(58, 115, 230, 0.08)" | "rgba(77, 136, 255, 0.08)";
    '--ig-color-blue-tint-10': "rgba(58, 115, 230, 0.1)" | "rgba(77, 136, 255, 0.1)";
    '--ig-color-blue-tint-12': string;
    '--ig-color-blue-tint-14': string;
    '--ig-color-blue-tint-15': "rgba(77, 136, 255, 0.15)" | "rgba(58, 115, 230, 0.15)";
    '--ig-color-blue-tint-16': string;
    '--ig-color-blue-tint-18': string;
    '--ig-color-blue-tint-20': "rgba(58, 115, 230, 0.2)" | "rgba(77, 136, 255, 0.2)";
    '--ig-color-blue-tint-25': "rgba(58, 115, 230, 0.25)" | "rgba(77, 136, 255, 0.25)";
    '--ig-color-blue-tint-28': string;
    '--ig-color-blue-tint-35': "rgba(58, 115, 230, 0.35)" | "rgba(77, 136, 255, 0.35)";
    '--ig-color-blue-tint-38': string;
    '--ig-color-blue-tint-40': "rgba(77, 136, 255, 0.4)" | "rgba(58, 115, 230, 0.4)";
    '--ig-color-blue-tint-50': "rgba(58, 115, 230, 0.5)" | "rgba(77, 136, 255, 0.5)";
    '--ig-color-blue-tint-55': "rgba(58, 115, 230, 0.55)" | "rgba(77, 136, 255, 0.55)";
    '--ig-color-blue-tint-60': "rgba(58, 115, 230, 0.6)" | "rgba(77, 136, 255, 0.6)";
    '--ig-color-blue-tint-70': "rgba(58, 115, 230, 0.7)" | "rgba(77, 136, 255, 0.7)";
    '--ig-color-blue-tint-78': "rgba(58, 115, 230, 0.78)" | "rgba(77, 136, 255, 0.78)";
    '--ig-color-blue-tint-80': "rgba(58, 115, 230, 0.8)" | "rgba(77, 136, 255, 0.8)";
    '--ig-color-blue-tint-85': "rgba(58, 115, 230, 0.85)" | "rgba(77, 136, 255, 0.85)";
    '--ig-color-blue-tint-90': "rgba(58, 115, 230, 0.9)" | "rgba(77, 136, 255, 0.9)";
    '--ig-color-blue-tint-92': "rgba(58, 115, 230, 0.92)" | "rgba(77, 136, 255, 0.92)";
    '--ig-color-blue-tint-62': "rgba(58, 115, 230, 0.62)" | "rgba(77, 136, 255, 0.62)";
    '--ig-color-blue-tint-34': "rgba(58, 115, 230, 0.34)" | "rgba(77, 136, 255, 0.34)";
    '--ig-color-blue-strong-tint-20': "rgba(20, 63, 166, 0.2)" | "rgba(41, 98, 217, 0.2)";
    '--ig-color-blue-strong-tint-24': "rgba(20, 63, 166, 0.24)" | "rgba(41, 98, 217, 0.24)";
    '--ig-color-blue-strong-tint-30': "rgba(20, 63, 166, 0.3)" | "rgba(41, 98, 217, 0.3)";
    '--ig-color-slate-tint-86': "rgba(229, 231, 235, 0.86)" | "rgba(75, 85, 99, 0.86)";
    '--ig-color-white-32': "rgba(15, 18, 25, 0.24)" | "rgba(255, 255, 255, 0.32)";
    '--ig-color-white-35': "rgba(15, 18, 25, 0.27)" | "rgba(255, 255, 255, 0.35)";
    '--ig-color-white-45': "rgba(15, 18, 25, 0.37)" | "rgba(255, 255, 255, 0.45)";
    '--ig-color-white-55': "rgba(15, 18, 25, 0.47)" | "rgba(255, 255, 255, 0.55)";
    '--ig-color-white-62': "rgba(15, 18, 25, 0.54)" | "rgba(255, 255, 255, 0.62)";
    '--ig-color-white-80': "rgba(15, 18, 25, 0.72)" | "rgba(255, 255, 255, 0.8)";
    '--ig-color-overlay-archived': "rgba(0, 0, 0, 0.36)";
    '--ig-color-overlay-darker': "rgba(0, 0, 0, 0.48)" | "rgba(0, 0, 0, 0.65)";
    '--ig-color-overlay-darkest': "rgba(0, 0, 0, 0.62)" | "rgba(0, 0, 0, 0.82)";
    '--ig-color-overlay-near-opaque': "rgba(0, 0, 0, 0.72)" | "rgba(0, 0, 0, 0.92)";
    '--ig-color-capture-surface-loud': "rgba(229, 231, 235, 0.86)" | "rgba(17, 24, 39, 0.86)";
    '--ig-color-capture-surface': "rgba(229, 231, 235, 0.7)" | "rgba(17, 24, 39, 0.7)";
    '--ig-color-capture-overlay': "rgba(0, 0, 0, 0.36)" | "rgba(0, 0, 0, 0.24)";
    '--ig-color-app-backdrop': "rgba(0, 0, 0, 0.22)" | "rgba(0, 0, 0, 0.32)";
    '--ig-color-yellow-tint-50': "rgba(202, 138, 4, 0.5)" | "rgba(255, 255, 0, 0.5)";
    '--ig-color-slate-gray-tint-12': "rgba(71, 85, 105, 0.12)" | "rgba(127, 139, 157, 0.12)";
    '--ig-color-slate-gray-tint-16': "rgba(71, 85, 105, 0.16)" | "rgba(127, 139, 157, 0.16)";
    '--ig-color-slate-gray-tint-18': "rgba(71, 85, 105, 0.18)" | "rgba(127, 139, 157, 0.18)";
    '--ig-color-overlay-deep': "rgba(0, 0, 0, 0.58)" | "rgba(0, 0, 0, 0.78)";
    '--ig-color-capture-bg-loud': "rgba(229, 231, 235, 0.82)" | "rgba(12, 16, 22, 0.82)";
    '--ig-color-blue-accent-solid': "rgba(58, 115, 230, 1)" | "rgba(77, 136, 255, 1)";
    '--ig-color-surface-dropdown-grid-top': "rgba(255, 255, 255, 0.98)" | "rgba(18, 24, 34, 0.98)";
    '--ig-color-surface-dropdown-grid-bottom': "rgba(247, 249, 251, 0.98)" | "rgba(12, 16, 24, 0.98)";
    '--ig-color-green-tint-success-soft': "rgba(22, 163, 74, 0.08)" | "rgba(52, 211, 153, 0.06)";
    '--ig-color-amber-tint-warning-soft': "rgba(217, 119, 6, 0.08)" | "rgba(250, 204, 21, 0.06)";
    '--ig-color-project-tag-general': "rgba(71, 85, 105, 0.92)" | "rgba(100, 116, 139, 0.92)";
    '--ig-color-project-tag-deflectometry': "rgba(2, 132, 199, 0.92)" | "rgba(14, 165, 233, 0.92)";
    '--ig-color-project-tag-photometric-stereo': "rgba(124, 58, 237, 0.92)" | "rgba(167, 139, 250, 0.92)";
    '--ig-radius-2xs': "6px";
    '--ig-radius-xxs': "8px";
    '--ig-radius-xs': "10px";
    '--ig-radius-sm': string;
    '--ig-radius-md': string;
    '--ig-radius-lg': string;
    '--ig-radius-xl': string;
    '--ig-radius-2xl': "20px";
    '--ig-radius-4xl': "24px";
    '--ig-radius-pill': string;
    '--ig-font-sans': string;
    '--ig-font-mono': string;
    '--ig-font-size-3xs': "10px";
    '--ig-font-size-2xs': "11px";
    '--ig-font-size-xs': "12px";
    '--ig-font-size-sm': "13px";
    '--ig-font-size-md': "14px";
    '--ig-font-size-lg': "15px";
    '--ig-font-size-xl': "16px";
    '--ig-font-size-2xl': "18px";
    '--ig-font-size-3xl': "20px";
    '--ig-font-size-3xl-plus': "22px";
    '--ig-font-size-4xl': "24px";
    '--ig-font-size-5xl': "28px";
    '--ig-font-size-state-title': "13px";
    '--ig-font-size-state-description': "12px";
    '--ig-font-weight-state-title': "600";
    '--ig-line-height-state-description': "1.5";
    '--ig-font-weight-regular': string;
    '--ig-font-weight-medium': string;
    '--ig-font-weight-semibold': string;
    '--ig-font-weight-bold': string;
    '--ig-font-weight-black': string;
    '--ig-letter-spacing-heading': "-0.02em";
    '--ig-text-clamp-narrow': "5.5em";
    '--ig-text-clamp-mid': "8em";
    '--ig-letter-spacing-micro': "0.01em";
    '--ig-letter-spacing-tight': "0.03em";
    '--ig-letter-spacing-normal': "0.04em";
    '--ig-letter-spacing-wide': "0.05em";
    '--ig-letter-spacing-wider': "0.06em";
    '--ig-letter-spacing-widest': "0.08em";
    '--ig-line-height-none': string;
    '--ig-line-height-tight': string;
    '--ig-line-height-snug': string;
    '--ig-line-height-base': string;
    '--ig-line-height-relaxed': string;
    '--ig-line-height-relaxed-plus': string;
    '--ig-line-height-loose': string;
    '--ig-opacity-svg-fill-faint': string;
    '--ig-opacity-svg-fill-subtle': string;
    '--ig-opacity-svg-fill-soft': string;
    '--ig-opacity-svg-fill-medium': string;
    '--ig-opacity-ghost': string;
    '--ig-opacity-faded': string;
    '--ig-opacity-disabled': string;
    '--ig-opacity-overlay': string;
    '--ig-opacity-muted': string;
    '--ig-opacity-subtle': string;
    '--ig-opacity-emphatic': string;
    '--ig-opacity-loud': string;
    '--ig-opacity-loud-plus': string;
    '--ig-opacity-prominent': string;
    '--ig-opacity-near': string;
    '--ig-blur-2xs': "blur(1px)";
    '--ig-blur-xs': "blur(8px)";
    '--ig-blur-sm': "blur(14px)";
    '--ig-blur-md': "blur(16px)";
    '--ig-blur-lg': "blur(10px)";
    '--ig-blur-xl': "blur(12px)";
    '--ig-icon-xs': "12px";
    '--ig-icon-sub': "8px";
    '--ig-icon-2xs': "11px";
    '--ig-icon-sm': "14px";
    '--ig-icon-sm-plus': "15px";
    '--ig-icon-md': "16px";
    '--ig-icon-lg': "18px";
    '--ig-icon-xl': "20px";
    '--ig-icon-2xl': "22px";
    '--ig-icon-3xl': "24px";
    '--ig-svg-stroke-bold': string;
    '--ig-popup-3xs': "80px";
    '--ig-popup-2xs': "140px";
    '--ig-popup-2xs-plus': "160px";
    '--ig-popup-xs': "220px";
    '--ig-popup-sm': "280px";
    '--ig-popup-md': "320px";
    '--ig-popup-lg': "360px";
    '--ig-popup-xl': "480px";
    '--ig-popup-2xl-narrow': "420px";
    '--ig-popup-2xl': "560px";
    '--ig-popup-3xl': "920px";
    '--ig-popup-xs-tight': "210px";
    '--ig-popup-2xl-wide': "520px";
    '--ig-popup-3xl-narrow': "640px";
    '--ig-popup-3xl-mid': "720px";
    '--ig-popup-3xl-wide': "820px";
    '--ig-popup-4xl-narrow': "960px";
    '--ig-popup-4xl-mid': "1120px";
    '--ig-popup-4xl': "1200px";
    '--ig-popup-list-min': "200px";
    '--ig-popup-md-narrow': "300px";
    '--ig-popup-xs-plus': "240px";
    '--ig-popup-xs-narrow': "190px";
    '--ig-popup-sm-narrow': "260px";
    '--ig-popup-2xs-narrow': "120px";
    '--ig-popup-3xs-plus': "96px";
    '--ig-popup-3xs-wide': "104px";
    '--ig-popup-2xs-narrow-tight': "116px";
    '--ig-popup-2xs-tight': "124px";
    '--ig-popup-lg-plus': "440px";
    '--ig-popup-filter-panel': "380px";
    '--ig-space-0': "0px";
    '--ig-space-1px': "1px";
    '--ig-space-2px': "2px";
    '--ig-space-3px': "3px";
    '--ig-space-neg-1px': "-1px";
    '--ig-space-neg-2px': "-2px";
    '--ig-transform-hover-lift-y': "-1px";
    '--ig-space-1': "4px";
    '--ig-space-1-plus': "5px";
    '--ig-space-2': "6px";
    '--ig-space-2-plus': "7px";
    '--ig-space-3': "8px";
    '--ig-space-4': "10px";
    '--ig-space-5': "12px";
    '--ig-space-6': "14px";
    '--ig-space-7': "16px";
    '--ig-space-8': "18px";
    '--ig-space-9': "20px";
    '--ig-space-10': "22px";
    '--ig-space-11': "24px";
    '--ig-space-12': "28px";
    '--ig-space-13': "32px";
    '--ig-border-1px': "1px";
    '--ig-border-2px': "2px";
    '--ig-border-3px': "3px";
    '--ig-z-hidden': string;
    '--ig-z-base': string;
    '--ig-z-raised': string;
    '--ig-z-raised-plus': string;
    '--ig-z-capture': string;
    '--ig-z-capture-high': string;
    '--ig-z-capture-super': string;
    '--ig-z-capture-top': string;
    '--ig-z-sticky': string;
    '--ig-z-sticky-plus': string;
    '--ig-z-sticky-top': string;
    '--ig-z-header': string;
    '--ig-z-overlay': string;
    '--ig-z-overlay-low': string;
    '--ig-z-dot-menu': string;
    '--ig-z-dot-menu-plus': string;
    '--ig-z-topbar': string;
    '--ig-z-dropdown': string;
    '--ig-z-mobile-nav-backdrop': string;
    '--ig-z-mobile-nav': string;
    '--ig-z-mobile-menu': string;
    '--ig-z-popover': string;
    '--ig-z-context-menu': string;
    '--ig-z-drawer': string;
    '--ig-z-modal': string;
    '--ig-z-toast': string;
    '--ig-z-tooltip': string;
    '--ig-scale-press': string;
    '--ig-scale-drag': string;
    '--ig-scale-hover-lift': string;
    '--ig-aspect-landscape': "4 / 3";
    '--ig-control-height-xs': "28px";
    '--ig-control-height-xs-plus': "30px";
    '--ig-control-height-sm': "32px";
    '--ig-control-height-sm-plus': "34px";
    '--ig-control-height-md': "36px";
    '--ig-control-height-mid-plus': "40px";
    '--ig-control-height-mid-plus-tall': "60px";
    '--ig-control-height-2xl-wide': "56px";
    '--ig-control-height-lg': "44px";
    '--ig-control-height-xl': "48px";
    '--ig-control-height-2xl': "52px";
    '--ig-control-height-3xl': "60px";
    '--ig-control-height-3xl-plus': "64px";
    '--ig-page-max-width': "1280px";
    '--ig-layout-topbar': "80px";
    '--ig-layout-capture-bar': "100px";
    '--ig-layout-capture-grid': "100px";
    '--ig-layout-histogram-width': "224px";
    '--ig-layout-histogram-height': "84px";
    '--ig-layout-dataset-card-min-height': "112px";
    '--ig-layout-dataset-card-recent-min-height': "108px";
    '--ig-layout-log-time-min': "45px";
    '--ig-layout-log-detail-left': "254px";
    '--ig-layout-log-detail-top': "58px";
    '--ig-layout-log-detail-width': "272px";
    '--ig-layout-color-plane-height': "120px";
    '--ig-layout-color-thumb-size': "18px";
    '--ig-layout-shadow-y-offset': "40px";
    '--ig-layout-shadow-blur': "80px";
    '--ig-layout-sidebar-header': "72px";
    '--ig-layout-sidebar-collapse': "100px";
    '--ig-layout-panel-min-height': "300px";
    '--ig-layout-loading-panel-height': "180px";
    '--ig-form-label-col': "140px";
    '--ig-form-label-col-wide': "160px";
    '--ig-motion-fastest': "0.12s";
    '--ig-motion-swift': "0.15s";
    '--ig-motion-fast': "0.16s ease";
    '--ig-motion-fast-ease': "0.16s ease";
    '--ig-motion-normal': "0.24s ease";
    '--ig-motion-normal-ease': "0.2s ease";
    '--ig-motion-mobile-nav': "0.28s cubic-bezier(0.4, 0, 0.2, 1)";
    '--ig-motion-spinner': "0.7s";
    '--ig-motion-spinner-fast': "0.75s";
    '--ig-motion-spinner-slow': "0.8s";
    '--ig-motion-progress-bar': "1.2s";
    '--ig-motion-sync-spin': "1.5s";
    '--ig-motion-shimmer': "1s";
    '--ig-motion-skeleton': "1.3s";
};
declare const tokenCssVariables: {
    '--ig-color-bg-canvas': string;
    '--ig-color-bg-radial-a': string;
    '--ig-color-bg-radial-b': string;
    '--ig-color-surface-header': string;
    '--ig-color-surface-panel': string;
    '--ig-color-surface-raised': string;
    '--ig-color-surface-muted': string;
    '--ig-color-surface-interactive': string;
    '--ig-color-surface-active': string;
    '--ig-color-border-subtle': string;
    '--ig-color-border-strong': string;
    '--ig-color-text-primary': string;
    '--ig-color-text-secondary': string;
    '--ig-color-text-muted': string;
    '--ig-color-text-soft': string;
    '--ig-color-state-title': string;
    '--ig-color-state-description': string;
    '--ig-color-accent': string;
    '--ig-color-accent-strong': string;
    '--ig-color-accent-soft': string;
    '--ig-color-success': string;
    '--ig-color-warning': string;
    '--ig-color-danger': string;
    '--ig-color-surface-card-a': "rgba(255, 255, 255, 0.96)" | "rgba(18, 21, 28, 0.96)";
    '--ig-color-surface-card-b': "rgba(247, 249, 251, 0.96)" | "rgba(10, 14, 20, 0.96)";
    '--ig-color-surface-interactive-hover': string;
    '--ig-color-surface-focus': "rgba(255, 255, 255, 0.98)" | "rgba(16, 22, 32, 0.98)";
    '--ig-color-accent-ring': "rgba(58, 115, 230, 0.55)" | "rgba(91, 144, 255, 0.7)";
    '--ig-color-accent-border-strong': string;
    '--ig-color-accent-soft-surface': string;
    '--ig-color-accent-soft-surface-hover': string;
    '--ig-color-on-accent': "#ffffff";
    '--ig-shadow-panel': string;
    '--ig-shadow-floating': string;
    '--ig-shadow-popover': string;
    '--ig-shadow-menu': string;
    '--ig-shadow-hover-lift': string;
    '--ig-shadow-focus-ring': string;
    '--ig-shadow-drawer-lift': string;
    '--ig-shadow-danger-hover-lift': string;
    '--ig-shadow-control-elevated': string;
    '--ig-scrollbar-thumb': "rgba(15, 23, 42, 0.18)" | "rgba(148, 163, 184, 0.22)";
    '--ig-scrollbar-thumb-hover': "rgba(15, 23, 42, 0.28)" | "rgba(148, 163, 184, 0.34)";
    '--ig-scrollbar-thumb-active': "rgba(15, 23, 42, 0.36)" | "rgba(148, 163, 184, 0.42)";
    '--ig-color-status-running-bg': string;
    '--ig-color-status-running-text': string;
    '--ig-color-status-completed-bg': string;
    '--ig-color-status-completed-text': string;
    '--ig-color-status-queued-bg': string;
    '--ig-color-status-queued-text': string;
    '--ig-color-status-draft-bg': string;
    '--ig-color-status-draft-text': string;
    '--ig-color-status-failed-bg': string;
    '--ig-color-status-failed-text': string;
    '--ig-color-status-stopped-bg': "rgba(15, 23, 42, 0.10)" | "rgba(148, 163, 184, 0.16)";
    '--ig-color-status-stopped-text': string;
    '--ig-color-status-interrupted-bg': string;
    '--ig-color-status-interrupted-text': string;
    '--ig-color-status-warning-bg': string;
    '--ig-color-status-warning-text': string;
    '--ig-color-status-idle-bg': "rgba(15, 23, 42, 0.10)" | "rgba(67, 76, 94, 0.22)";
    '--ig-color-status-idle-text': string;
    '--ig-color-alert-info-bg': string;
    '--ig-color-alert-info-border': "rgba(58, 115, 230, 0.32)" | "rgba(77, 136, 255, 0.26)";
    '--ig-color-alert-info-text': string;
    '--ig-color-alert-success-bg': string;
    '--ig-color-alert-success-border': "rgba(26, 143, 111, 0.32)" | "rgba(43, 181, 114, 0.26)";
    '--ig-color-alert-success-text': string;
    '--ig-color-alert-warning-bg': "rgba(184, 118, 26, 0.12)" | "rgba(251, 146, 60, 0.12)";
    '--ig-color-alert-warning-border': "rgba(184, 118, 26, 0.32)" | "rgba(251, 146, 60, 0.26)";
    '--ig-color-alert-warning-text': string;
    '--ig-color-alert-danger-bg': string;
    '--ig-color-alert-danger-border': "rgba(204, 41, 41, 0.32)" | "rgba(239, 68, 68, 0.26)";
    '--ig-color-alert-danger-text': string;
    '--ig-color-chart-1': string;
    '--ig-color-chart-2': string;
    '--ig-color-chart-3': string;
    '--ig-color-chart-4': string;
    '--ig-color-chart-5': string;
    '--ig-color-chart-6': string;
    '--ig-color-chart-grid': "rgba(15, 23, 42, 0.08)" | "var(--ig-color-white-08)";
    '--ig-color-chart-separator': "rgba(255, 255, 255, 0.82)" | "rgba(10, 14, 20, 0.62)";
    '--ig-color-badge-neutral': string;
    '--ig-color-badge-accent': string;
    '--ig-color-badge-success': string;
    '--ig-color-badge-warning': string;
    '--ig-color-badge-danger': string;
    '--ig-color-tag-classification-bg': string;
    '--ig-color-tag-classification-text': string;
    '--ig-color-tag-segmentation-bg': string;
    '--ig-color-tag-segmentation-text': string;
    '--ig-color-tag-object-detection-bg': string;
    '--ig-color-sync-chip-synced-bg': string;
    '--ig-color-sync-chip-uploading-bg': string;
    '--ig-color-sync-chip-failed-bg': string;
    '--ig-color-sync-chip-local-bg': string;
    '--ig-color-sync-chip-on-text': string;
    '--ig-color-image-option-bg': "rgba(0, 0, 0, 0.5)" | "rgba(0, 0, 0, 0.6)";
    '--ig-color-image-option-bg-hover': "rgba(0, 0, 0, 0.7)" | "rgba(0, 0, 0, 0.8)";
    '--ig-color-image-group-circle-bg': string;
    '--ig-color-image-group-circle-border': string;
    '--ig-color-danger-dim-bg': string;
    '--ig-color-danger-dim-border': string;
    '--ig-color-progress-track': string;
    '--ig-color-skeleton-start': string;
    '--ig-color-skeleton-mid': string;
    '--ig-color-image-card-hover-border': string;
    '--ig-color-image-card-selected-border': string;
    '--ig-color-image-card-selected-ring': string;
    '--ig-color-image-card-gradient-a': string;
    '--ig-color-image-card-gradient-b': string;
    '--ig-color-avatar-bg': string;
    '--ig-color-selection-bg': string;
    '--ig-color-focus-bg-soft': string;
    '--ig-color-active-bg': string;
    '--ig-color-danger-bg-soft': "rgba(220, 38, 38, 0.10)" | "rgba(239, 68, 68, 0.08)";
    '--ig-color-danger-bg': "rgba(239, 68, 68, 0.12)" | "rgba(220, 38, 38, 0.14)";
    '--ig-color-danger-bg-hover': "rgba(239, 68, 68, 0.18)" | "rgba(220, 38, 38, 0.20)";
    '--ig-color-danger-bg-strong': "rgba(220, 38, 38, 0.6)" | "rgba(239, 68, 68, 0.6)";
    '--ig-color-danger-overlay': "rgba(220, 38, 38, 0.92)" | "rgba(239, 68, 68, 0.92)";
    '--ig-color-danger-overlay-hover': "rgba(185, 28, 28, 0.96)" | "rgba(220, 38, 38, 0.96)";
    '--ig-color-danger-button-bg': "rgba(220, 38, 60, 0.20)" | "rgba(255, 95, 122, 0.18)";
    '--ig-color-danger-button-border': "rgba(220, 38, 60, 0.30)" | "rgba(255, 95, 122, 0.28)";
    '--ig-color-success-bg-soft': "rgba(22, 163, 74, 0.10)" | "rgba(43, 181, 114, 0.08)";
    '--ig-color-success-bg': "rgba(22, 163, 74, 0.18)" | "rgba(60, 210, 120, 0.15)";
    '--ig-color-warning-bg': "rgba(217, 119, 6, 0.18)" | "rgba(255, 180, 60, 0.15)";
    '--ig-color-dropdown-open-shadow': "0 0 0 3px rgba(58, 115, 230, 0.20), 0 18px 36px rgba(15, 23, 42, 0.10)" | "0 0 0 3px var(--ig-color-blue-tint-16), 0 18px 36px rgba(0, 0, 0, 0.18)";
    '--ig-color-dropdown-menu-a': "rgba(255, 255, 255, 0.98)" | "rgba(18, 24, 34, 0.98)";
    '--ig-color-dropdown-menu-b': "rgba(247, 249, 251, 0.98)" | "rgba(10, 14, 20, 0.98)";
    '--ig-color-dropdown-option-hover': string;
    '--ig-color-toggle-on-bg': "rgba(58, 115, 230, 0.5)" | "rgba(77, 136, 255, 0.4)";
    '--ig-color-toggle-on-border': "rgba(58, 115, 230, 0.65)" | "rgba(77, 136, 255, 0.55)";
    '--ig-color-toggle-off-bg': string;
    '--ig-color-toggle-off-border': string;
    '--ig-color-tab-surface': string;
    '--ig-color-tab-highlight': string;
    '--ig-color-toolbar-surface': "rgba(247, 249, 251, 0.84)" | "rgba(8, 12, 18, 0.84)";
    '--ig-color-modal-backdrop': string;
    '--ig-color-overlay-dim': "rgba(0, 0, 0, 0.45)";
    '--ig-color-overlay-mid': "rgba(0, 0, 0, 0.5)";
    '--ig-color-overlay-strong': "rgba(0, 0, 0, 0.55)";
    '--ig-color-lightbox-backdrop': "rgba(0, 0, 0, 0.85)";
    '--ig-color-lightbox-surface': "rgba(255, 255, 255, 0.7)" | "rgba(7, 10, 20, 0.7)";
    '--ig-color-sidebar-bg-top': "rgba(247, 249, 251, 0.96)" | "rgba(12, 15, 20, 0.96)";
    '--ig-color-sidebar-bg-bottom': "rgba(241, 245, 249, 0.94)" | "rgba(10, 14, 20, 0.94)";
    '--ig-color-surface-dropdown-mobile-top': "rgba(255, 255, 255, 0.98)" | "rgba(18, 24, 34, 0.98)";
    '--ig-color-surface-dropdown-mobile-bottom': "rgba(247, 249, 251, 0.98)" | "rgba(10, 14, 20, 0.98)";
    '--ig-color-surface-calendar-top': "rgba(255, 255, 255, 0.96)" | "rgba(17, 23, 32, 0.96)";
    '--ig-color-surface-calendar-bottom': "rgba(247, 249, 251, 0.96)" | "rgba(10, 14, 20, 0.96)";
    '--ig-color-danger-soft-surface': "rgba(220, 38, 38, 0.12)" | "rgba(164, 44, 44, 0.22)";
    '--ig-color-danger-button-gradient-mid': "#a23030" | "#7f1d1d";
    '--ig-color-danger-button-gradient-end': "#b13838" | "#8f2f2f";
    '--ig-color-danger-button-text': "#ffffff" | "#fff4f4";
    '--ig-color-danger-button-text-strong': "#ffffff" | "#ffe1e1";
    '--ig-color-svg-stroke-on-overlay': "#ffffff";
    '--ig-color-pie-slice-label': "#0f1219" | "#eef4ff";
    '--ig-color-annotation-outline-dark': "var(--ig-color-image-option-bg)";
    '--ig-color-annotation-outline-light': "rgba(255, 255, 255, 0.9)";
    '--ig-color-white-04': string;
    '--ig-color-white-06': string;
    '--ig-color-white-07': string;
    '--ig-color-white-08': string;
    '--ig-color-white-10': string;
    '--ig-color-white-12': string;
    '--ig-color-white-18': string;
    '--ig-color-white-20': "rgba(15, 18, 25, 0.16)" | "rgba(255, 255, 255, 0.2)";
    '--ig-color-white-24': string;
    '--ig-color-white-30': "rgba(15, 18, 25, 0.22)" | "rgba(255, 255, 255, 0.3)";
    '--ig-color-white-40': "rgba(15, 18, 25, 0.32)" | "rgba(255, 255, 255, 0.4)";
    '--ig-color-white-70': "rgba(255, 255, 255, 0.7)" | "rgba(15, 18, 25, 0.62)";
    '--ig-color-white-90': "rgba(255, 255, 255, 0.9)" | "rgba(15, 18, 25, 0.82)";
    '--ig-color-white-96': "rgba(255, 255, 255, 0.96)" | "rgba(15, 18, 25, 0.88)";
    '--ig-color-inset-highlight': "rgba(15, 18, 25, 0.05)" | "rgba(255, 255, 255, 0.05)";
    '--ig-color-slate-tint-18': string;
    '--ig-color-blue-tint-06': "rgba(58, 115, 230, 0.06)" | "rgba(77, 136, 255, 0.06)";
    '--ig-color-blue-tint-08': "rgba(58, 115, 230, 0.08)" | "rgba(77, 136, 255, 0.08)";
    '--ig-color-blue-tint-10': "rgba(58, 115, 230, 0.1)" | "rgba(77, 136, 255, 0.1)";
    '--ig-color-blue-tint-12': string;
    '--ig-color-blue-tint-14': string;
    '--ig-color-blue-tint-15': "rgba(77, 136, 255, 0.15)" | "rgba(58, 115, 230, 0.15)";
    '--ig-color-blue-tint-16': string;
    '--ig-color-blue-tint-18': string;
    '--ig-color-blue-tint-20': "rgba(58, 115, 230, 0.2)" | "rgba(77, 136, 255, 0.2)";
    '--ig-color-blue-tint-25': "rgba(58, 115, 230, 0.25)" | "rgba(77, 136, 255, 0.25)";
    '--ig-color-blue-tint-28': string;
    '--ig-color-blue-tint-35': "rgba(58, 115, 230, 0.35)" | "rgba(77, 136, 255, 0.35)";
    '--ig-color-blue-tint-38': string;
    '--ig-color-blue-tint-40': "rgba(77, 136, 255, 0.4)" | "rgba(58, 115, 230, 0.4)";
    '--ig-color-blue-tint-50': "rgba(58, 115, 230, 0.5)" | "rgba(77, 136, 255, 0.5)";
    '--ig-color-blue-tint-55': "rgba(58, 115, 230, 0.55)" | "rgba(77, 136, 255, 0.55)";
    '--ig-color-blue-tint-60': "rgba(58, 115, 230, 0.6)" | "rgba(77, 136, 255, 0.6)";
    '--ig-color-blue-tint-70': "rgba(58, 115, 230, 0.7)" | "rgba(77, 136, 255, 0.7)";
    '--ig-color-blue-tint-78': "rgba(58, 115, 230, 0.78)" | "rgba(77, 136, 255, 0.78)";
    '--ig-color-blue-tint-80': "rgba(58, 115, 230, 0.8)" | "rgba(77, 136, 255, 0.8)";
    '--ig-color-blue-tint-85': "rgba(58, 115, 230, 0.85)" | "rgba(77, 136, 255, 0.85)";
    '--ig-color-blue-tint-90': "rgba(58, 115, 230, 0.9)" | "rgba(77, 136, 255, 0.9)";
    '--ig-color-blue-tint-92': "rgba(58, 115, 230, 0.92)" | "rgba(77, 136, 255, 0.92)";
    '--ig-color-blue-tint-62': "rgba(58, 115, 230, 0.62)" | "rgba(77, 136, 255, 0.62)";
    '--ig-color-blue-tint-34': "rgba(58, 115, 230, 0.34)" | "rgba(77, 136, 255, 0.34)";
    '--ig-color-blue-strong-tint-20': "rgba(20, 63, 166, 0.2)" | "rgba(41, 98, 217, 0.2)";
    '--ig-color-blue-strong-tint-24': "rgba(20, 63, 166, 0.24)" | "rgba(41, 98, 217, 0.24)";
    '--ig-color-blue-strong-tint-30': "rgba(20, 63, 166, 0.3)" | "rgba(41, 98, 217, 0.3)";
    '--ig-color-slate-tint-86': "rgba(229, 231, 235, 0.86)" | "rgba(75, 85, 99, 0.86)";
    '--ig-color-white-32': "rgba(15, 18, 25, 0.24)" | "rgba(255, 255, 255, 0.32)";
    '--ig-color-white-35': "rgba(15, 18, 25, 0.27)" | "rgba(255, 255, 255, 0.35)";
    '--ig-color-white-45': "rgba(15, 18, 25, 0.37)" | "rgba(255, 255, 255, 0.45)";
    '--ig-color-white-55': "rgba(15, 18, 25, 0.47)" | "rgba(255, 255, 255, 0.55)";
    '--ig-color-white-62': "rgba(15, 18, 25, 0.54)" | "rgba(255, 255, 255, 0.62)";
    '--ig-color-white-80': "rgba(15, 18, 25, 0.72)" | "rgba(255, 255, 255, 0.8)";
    '--ig-color-overlay-archived': "rgba(0, 0, 0, 0.36)";
    '--ig-color-overlay-darker': "rgba(0, 0, 0, 0.48)" | "rgba(0, 0, 0, 0.65)";
    '--ig-color-overlay-darkest': "rgba(0, 0, 0, 0.62)" | "rgba(0, 0, 0, 0.82)";
    '--ig-color-overlay-near-opaque': "rgba(0, 0, 0, 0.72)" | "rgba(0, 0, 0, 0.92)";
    '--ig-color-capture-surface-loud': "rgba(229, 231, 235, 0.86)" | "rgba(17, 24, 39, 0.86)";
    '--ig-color-capture-surface': "rgba(229, 231, 235, 0.7)" | "rgba(17, 24, 39, 0.7)";
    '--ig-color-capture-overlay': "rgba(0, 0, 0, 0.36)" | "rgba(0, 0, 0, 0.24)";
    '--ig-color-app-backdrop': "rgba(0, 0, 0, 0.22)" | "rgba(0, 0, 0, 0.32)";
    '--ig-color-yellow-tint-50': "rgba(202, 138, 4, 0.5)" | "rgba(255, 255, 0, 0.5)";
    '--ig-color-slate-gray-tint-12': "rgba(71, 85, 105, 0.12)" | "rgba(127, 139, 157, 0.12)";
    '--ig-color-slate-gray-tint-16': "rgba(71, 85, 105, 0.16)" | "rgba(127, 139, 157, 0.16)";
    '--ig-color-slate-gray-tint-18': "rgba(71, 85, 105, 0.18)" | "rgba(127, 139, 157, 0.18)";
    '--ig-color-overlay-deep': "rgba(0, 0, 0, 0.58)" | "rgba(0, 0, 0, 0.78)";
    '--ig-color-capture-bg-loud': "rgba(229, 231, 235, 0.82)" | "rgba(12, 16, 22, 0.82)";
    '--ig-color-blue-accent-solid': "rgba(58, 115, 230, 1)" | "rgba(77, 136, 255, 1)";
    '--ig-color-surface-dropdown-grid-top': "rgba(255, 255, 255, 0.98)" | "rgba(18, 24, 34, 0.98)";
    '--ig-color-surface-dropdown-grid-bottom': "rgba(247, 249, 251, 0.98)" | "rgba(12, 16, 24, 0.98)";
    '--ig-color-green-tint-success-soft': "rgba(22, 163, 74, 0.08)" | "rgba(52, 211, 153, 0.06)";
    '--ig-color-amber-tint-warning-soft': "rgba(217, 119, 6, 0.08)" | "rgba(250, 204, 21, 0.06)";
    '--ig-color-project-tag-general': "rgba(71, 85, 105, 0.92)" | "rgba(100, 116, 139, 0.92)";
    '--ig-color-project-tag-deflectometry': "rgba(2, 132, 199, 0.92)" | "rgba(14, 165, 233, 0.92)";
    '--ig-color-project-tag-photometric-stereo': "rgba(124, 58, 237, 0.92)" | "rgba(167, 139, 250, 0.92)";
    '--ig-radius-2xs': "6px";
    '--ig-radius-xxs': "8px";
    '--ig-radius-xs': "10px";
    '--ig-radius-sm': string;
    '--ig-radius-md': string;
    '--ig-radius-lg': string;
    '--ig-radius-xl': string;
    '--ig-radius-2xl': "20px";
    '--ig-radius-4xl': "24px";
    '--ig-radius-pill': string;
    '--ig-font-sans': string;
    '--ig-font-mono': string;
    '--ig-font-size-3xs': "10px";
    '--ig-font-size-2xs': "11px";
    '--ig-font-size-xs': "12px";
    '--ig-font-size-sm': "13px";
    '--ig-font-size-md': "14px";
    '--ig-font-size-lg': "15px";
    '--ig-font-size-xl': "16px";
    '--ig-font-size-2xl': "18px";
    '--ig-font-size-3xl': "20px";
    '--ig-font-size-3xl-plus': "22px";
    '--ig-font-size-4xl': "24px";
    '--ig-font-size-5xl': "28px";
    '--ig-font-size-state-title': "13px";
    '--ig-font-size-state-description': "12px";
    '--ig-font-weight-state-title': "600";
    '--ig-line-height-state-description': "1.5";
    '--ig-font-weight-regular': string;
    '--ig-font-weight-medium': string;
    '--ig-font-weight-semibold': string;
    '--ig-font-weight-bold': string;
    '--ig-font-weight-black': string;
    '--ig-letter-spacing-heading': "-0.02em";
    '--ig-text-clamp-narrow': "5.5em";
    '--ig-text-clamp-mid': "8em";
    '--ig-letter-spacing-micro': "0.01em";
    '--ig-letter-spacing-tight': "0.03em";
    '--ig-letter-spacing-normal': "0.04em";
    '--ig-letter-spacing-wide': "0.05em";
    '--ig-letter-spacing-wider': "0.06em";
    '--ig-letter-spacing-widest': "0.08em";
    '--ig-line-height-none': string;
    '--ig-line-height-tight': string;
    '--ig-line-height-snug': string;
    '--ig-line-height-base': string;
    '--ig-line-height-relaxed': string;
    '--ig-line-height-relaxed-plus': string;
    '--ig-line-height-loose': string;
    '--ig-opacity-svg-fill-faint': string;
    '--ig-opacity-svg-fill-subtle': string;
    '--ig-opacity-svg-fill-soft': string;
    '--ig-opacity-svg-fill-medium': string;
    '--ig-opacity-ghost': string;
    '--ig-opacity-faded': string;
    '--ig-opacity-disabled': string;
    '--ig-opacity-overlay': string;
    '--ig-opacity-muted': string;
    '--ig-opacity-subtle': string;
    '--ig-opacity-emphatic': string;
    '--ig-opacity-loud': string;
    '--ig-opacity-loud-plus': string;
    '--ig-opacity-prominent': string;
    '--ig-opacity-near': string;
    '--ig-blur-2xs': "blur(1px)";
    '--ig-blur-xs': "blur(8px)";
    '--ig-blur-sm': "blur(14px)";
    '--ig-blur-md': "blur(16px)";
    '--ig-blur-lg': "blur(10px)";
    '--ig-blur-xl': "blur(12px)";
    '--ig-icon-xs': "12px";
    '--ig-icon-sub': "8px";
    '--ig-icon-2xs': "11px";
    '--ig-icon-sm': "14px";
    '--ig-icon-sm-plus': "15px";
    '--ig-icon-md': "16px";
    '--ig-icon-lg': "18px";
    '--ig-icon-xl': "20px";
    '--ig-icon-2xl': "22px";
    '--ig-icon-3xl': "24px";
    '--ig-svg-stroke-bold': string;
    '--ig-popup-3xs': "80px";
    '--ig-popup-2xs': "140px";
    '--ig-popup-2xs-plus': "160px";
    '--ig-popup-xs': "220px";
    '--ig-popup-sm': "280px";
    '--ig-popup-md': "320px";
    '--ig-popup-lg': "360px";
    '--ig-popup-xl': "480px";
    '--ig-popup-2xl-narrow': "420px";
    '--ig-popup-2xl': "560px";
    '--ig-popup-3xl': "920px";
    '--ig-popup-xs-tight': "210px";
    '--ig-popup-2xl-wide': "520px";
    '--ig-popup-3xl-narrow': "640px";
    '--ig-popup-3xl-mid': "720px";
    '--ig-popup-3xl-wide': "820px";
    '--ig-popup-4xl-narrow': "960px";
    '--ig-popup-4xl-mid': "1120px";
    '--ig-popup-4xl': "1200px";
    '--ig-popup-list-min': "200px";
    '--ig-popup-md-narrow': "300px";
    '--ig-popup-xs-plus': "240px";
    '--ig-popup-xs-narrow': "190px";
    '--ig-popup-sm-narrow': "260px";
    '--ig-popup-2xs-narrow': "120px";
    '--ig-popup-3xs-plus': "96px";
    '--ig-popup-3xs-wide': "104px";
    '--ig-popup-2xs-narrow-tight': "116px";
    '--ig-popup-2xs-tight': "124px";
    '--ig-popup-lg-plus': "440px";
    '--ig-popup-filter-panel': "380px";
    '--ig-space-0': "0px";
    '--ig-space-1px': "1px";
    '--ig-space-2px': "2px";
    '--ig-space-3px': "3px";
    '--ig-space-neg-1px': "-1px";
    '--ig-space-neg-2px': "-2px";
    '--ig-transform-hover-lift-y': "-1px";
    '--ig-space-1': "4px";
    '--ig-space-1-plus': "5px";
    '--ig-space-2': "6px";
    '--ig-space-2-plus': "7px";
    '--ig-space-3': "8px";
    '--ig-space-4': "10px";
    '--ig-space-5': "12px";
    '--ig-space-6': "14px";
    '--ig-space-7': "16px";
    '--ig-space-8': "18px";
    '--ig-space-9': "20px";
    '--ig-space-10': "22px";
    '--ig-space-11': "24px";
    '--ig-space-12': "28px";
    '--ig-space-13': "32px";
    '--ig-border-1px': "1px";
    '--ig-border-2px': "2px";
    '--ig-border-3px': "3px";
    '--ig-z-hidden': string;
    '--ig-z-base': string;
    '--ig-z-raised': string;
    '--ig-z-raised-plus': string;
    '--ig-z-capture': string;
    '--ig-z-capture-high': string;
    '--ig-z-capture-super': string;
    '--ig-z-capture-top': string;
    '--ig-z-sticky': string;
    '--ig-z-sticky-plus': string;
    '--ig-z-sticky-top': string;
    '--ig-z-header': string;
    '--ig-z-overlay': string;
    '--ig-z-overlay-low': string;
    '--ig-z-dot-menu': string;
    '--ig-z-dot-menu-plus': string;
    '--ig-z-topbar': string;
    '--ig-z-dropdown': string;
    '--ig-z-mobile-nav-backdrop': string;
    '--ig-z-mobile-nav': string;
    '--ig-z-mobile-menu': string;
    '--ig-z-popover': string;
    '--ig-z-context-menu': string;
    '--ig-z-drawer': string;
    '--ig-z-modal': string;
    '--ig-z-toast': string;
    '--ig-z-tooltip': string;
    '--ig-scale-press': string;
    '--ig-scale-drag': string;
    '--ig-scale-hover-lift': string;
    '--ig-aspect-landscape': "4 / 3";
    '--ig-control-height-xs': "28px";
    '--ig-control-height-xs-plus': "30px";
    '--ig-control-height-sm': "32px";
    '--ig-control-height-sm-plus': "34px";
    '--ig-control-height-md': "36px";
    '--ig-control-height-mid-plus': "40px";
    '--ig-control-height-mid-plus-tall': "60px";
    '--ig-control-height-2xl-wide': "56px";
    '--ig-control-height-lg': "44px";
    '--ig-control-height-xl': "48px";
    '--ig-control-height-2xl': "52px";
    '--ig-control-height-3xl': "60px";
    '--ig-control-height-3xl-plus': "64px";
    '--ig-page-max-width': "1280px";
    '--ig-layout-topbar': "80px";
    '--ig-layout-capture-bar': "100px";
    '--ig-layout-capture-grid': "100px";
    '--ig-layout-histogram-width': "224px";
    '--ig-layout-histogram-height': "84px";
    '--ig-layout-dataset-card-min-height': "112px";
    '--ig-layout-dataset-card-recent-min-height': "108px";
    '--ig-layout-log-time-min': "45px";
    '--ig-layout-log-detail-left': "254px";
    '--ig-layout-log-detail-top': "58px";
    '--ig-layout-log-detail-width': "272px";
    '--ig-layout-color-plane-height': "120px";
    '--ig-layout-color-thumb-size': "18px";
    '--ig-layout-shadow-y-offset': "40px";
    '--ig-layout-shadow-blur': "80px";
    '--ig-layout-sidebar-header': "72px";
    '--ig-layout-sidebar-collapse': "100px";
    '--ig-layout-panel-min-height': "300px";
    '--ig-layout-loading-panel-height': "180px";
    '--ig-form-label-col': "140px";
    '--ig-form-label-col-wide': "160px";
    '--ig-motion-fastest': "0.12s";
    '--ig-motion-swift': "0.15s";
    '--ig-motion-fast': "0.16s ease";
    '--ig-motion-fast-ease': "0.16s ease";
    '--ig-motion-normal': "0.24s ease";
    '--ig-motion-normal-ease': "0.2s ease";
    '--ig-motion-mobile-nav': "0.28s cubic-bezier(0.4, 0, 0.2, 1)";
    '--ig-motion-spinner': "0.7s";
    '--ig-motion-spinner-fast': "0.75s";
    '--ig-motion-spinner-slow': "0.8s";
    '--ig-motion-progress-bar': "1.2s";
    '--ig-motion-sync-spin': "1.5s";
    '--ig-motion-shimmer': "1s";
    '--ig-motion-skeleton': "1.3s";
};

declare function renderVariableBlock(selector: string, variables: Record<string, string>): string;
declare function renderTokensCss(): string;

interface IngradientThemeProviderProps {
    children: React__default.ReactNode;
    /** Theme mode — toggles `data-theme` attr on html + selects styled-components theme. Default 'dark'. */
    mode?: ThemeMode;
    /** Override theme object directly (overrides `mode`). For custom themes. */
    theme?: IngradientTheme;
}
declare function IngradientThemeProvider({ children, mode, theme, }: IngradientThemeProviderProps): react_jsx_runtime.JSX.Element;

declare const IngradientGlobalStyle: React.NamedExoticComponent<styled_components.ExecutionProps & object>;

export { type BrandId, type ComposedPreset, type DensityId, IngradientGlobalStyle as DesignSystemGlobalStyle, IngradientGlobalStyle, type IngradientTheme, IngradientThemeProvider, type IngradientThemeProviderProps, IngradientGlobalStyle as PortalGlobalStyle, type Preset, PresetProvider, type PresetProviderProps, type PresetService, type ThemeId, type ThemeMode, IngradientThemeProvider as ThemeProvider, type TokenCategory, type TokenOverrides, appShell, aspectRatios, borderWidthScale, brandRegistry, breakpoints, buildTokenCssVariables, chartColors, chartHeights, comfortableDensity, compactDensity, composePreset, controlSizeNumbers, controlSizes, defaultBrand, densityRegistry, edgeV001, effectsScale, finemtechBrand, foundationColors, foundationColorsLight, gradientAngles, headerSurface, iconSizeNumbers, iconSizes, industrialDarkTheme, ingradientTheme, ingradientThemeDark, ingradientThemeLight, layoutScale, legacyPortalCssVariables, media, medicalDarkTheme, medicalV001, motionScale, opacityScale, pageContentLayout, pageHeaderSurface, platformV001, popupSizeNumbers, popupSizes, radiusScale, renderTokensCss, renderVariableBlock, rotations, samsungBrand, shadowScale, shadowScaleLight, spacingScale, svgStrokeWidths, themeRegistry, themes, tokenCssVariables, transformScale, typographyScale, ultraDenseDensity, usePreset, zIndexScale };
