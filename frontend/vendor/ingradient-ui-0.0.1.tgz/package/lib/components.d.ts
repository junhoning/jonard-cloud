import * as React$1 from 'react';
import React__default, { RefObject, ButtonHTMLAttributes, ReactNode, MouseEventHandler, TextareaHTMLAttributes, InputHTMLAttributes, HTMLAttributes, Component, ErrorInfo, MouseEvent, ImgHTMLAttributes, VideoHTMLAttributes } from 'react';
import { b as DrawingObject } from './types-CKU1Jsar.js';
export { C as CartesianSeries, D as DrawingAction, a as DrawingMode, c as DrawingPreview, G as GridSelectionAction, P as PieDatum, U as UseDrawingCanvasOptions, d as chartAxisTick, e as classifySelectionAction, u as useDrawingCanvas } from './types-CKU1Jsar.js';
import * as react_jsx_runtime from 'react/jsx-runtime';
import * as styled_components_dist_types from 'styled-components/dist/types';
import * as styled_components from 'styled-components';
import { F as FormatPatternTabItem } from './format-pattern-tab-BNsFrTcn.js';
import { DateRange } from 'react-day-picker';
import { S as StatusTone, a as alertToneStyles } from './charts-9G47m4fy.js';
export { c as chartPalette } from './charts-9G47m4fy.js';
import * as lucide_react from 'lucide-react';
export { X as ClosePanelIcon, Download as DownloadIcon, ExternalLink as ExportIcon, Filter as FilterIcon, LayoutGrid as GridIcon, MoreVertical as KebabIcon, Menu as MenuIcon, Plus as PlusIcon, Search as SearchIcon, ArrowUpDown as SortIcon, BarChart3 as StatsIcon, Table as TableIcon, Trash2 as TrashIcon, Upload as UploadIcon } from 'lucide-react';

interface UseZoomPanOptions {
    minZoom?: number;
    maxZoom?: number;
    zoomStep?: number;
    /** Optional — function returning the container dimensions. When provided, pan is
     *  clamped so the scaled content cannot move beyond `containerSize * (zoom - 1) / 2`
     *  on each side (image edges stay near canvas edges, no scroll past empty space). */
    getBounds?: () => {
        width: number;
        height: number;
    } | null;
}
declare function useZoomPan(options?: UseZoomPanOptions): {
    zoom: number;
    pan: {
        x: number;
        y: number;
    };
    reset: () => void;
    handleWheel: (e: WheelEvent) => void;
    startPan: (clientX: number, clientY: number, currentPanX: number, currentPanY: number) => void;
    movePan: (clientX: number, clientY: number) => boolean;
    endPan: () => void;
    isZoomPanning: () => boolean;
    hasPanned: () => boolean;
};

type SelectionAction = 'toggle' | 'range' | 'single';
declare function useSelection<T extends {
    id: string;
}>(items: T[]): {
    selectedIds: Set<string>;
    lastIndexRef: React$1.MutableRefObject<number | null>;
    clearSelection: () => void;
    selectAll: (ids?: string[]) => void;
    onSelectionChange: (action: SelectionAction, id: string, rangeStartId?: string) => void;
};

interface UseClipboardOptions {
    /** Duration in ms to keep `copied` true after a successful copy. Default 2000. */
    resetDelay?: number;
}
declare function useClipboard(options?: UseClipboardOptions): {
    copy: (text: string) => Promise<void>;
    copied: boolean;
};

interface UseUndoRedoOptions<T> {
    initialState: T;
    maxHistory?: number;
}
declare function useUndoRedo<T>({ initialState, maxHistory }: UseUndoRedoOptions<T>): {
    state: T;
    setState: (next: T) => void;
    undo: () => void;
    redo: () => void;
    canUndo: boolean;
    canRedo: boolean;
    reset: (newState: T) => void;
};

interface UseClickOutsideOptions {
    /** Single ref or list of refs. Click inside any of these is ignored. */
    refs: RefObject<HTMLElement | null> | RefObject<HTMLElement | null>[];
    /** Called when click happens outside all provided refs. */
    onClickOutside: () => void;
    /** Disable the listener (e.g. when dropdown is closed). Default: true */
    enabled?: boolean;
    /** Event type. 'mousedown' fires before click — closes dropdown before button activates. Default: 'click' */
    event?: 'click' | 'mousedown';
    /** Capture phase. Use when other handlers stopPropagation before bubble reaches document. Default: false */
    capture?: boolean;
}
declare function useClickOutside({ refs, onClickOutside, enabled, event, capture, }: UseClickOutsideOptions): void;

interface UseCanvasMouseConfig {
    /** Current tool — 'cursor' enables pan-when-zoomed + hit-test. */
    tool: 'cursor' | 'bbox' | 'point' | string;
    /** Current zoom level (from useZoomPan). canPan = (tool==='cursor' && zoom > 1). */
    zoom: number;
    /** Drawing object hit-test in normalized [0,1] coords. When true, click should
     *  go to drawing (resize/move) instead of pan. Default: checks rect bounds with
     *  a 12px hit padding (handles can stick out). */
    hitTestEditable?: (nx: number, ny: number) => boolean;
    /** Drawing objects — used by the default hit-test if `hitTestEditable` omitted. */
    drawingObjects?: DrawingObject[];
    /** Drawing bindings from useDrawingCanvas — onMouseDown/Move/Up/Leave. */
    drawingBindings: {
        onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
        onMouseMove: (event: React.MouseEvent<HTMLDivElement>) => void;
        onMouseUp: (event: React.MouseEvent<HTMLDivElement>) => void;
        onMouseLeave: () => void;
    };
    /** Caller-provided cursor when not in pan mode (e.g. from useDrawingCanvas.cursor). */
    drawingCursor: React.CSSProperties['cursor'];
    /** Zoom-pan API (from useZoomPan). */
    startPan: (clientX: number, clientY: number, currentPanX: number, currentPanY: number) => void;
    movePan: (clientX: number, clientY: number) => void;
    endPan: () => void;
    isZoomPanning: () => boolean;
    /** Current pan (for startPan currentPanX/Y arg). */
    pan: {
        x: number;
        y: number;
    };
    /** Ref to the capture element — for normalized coord calc. */
    containerRef: React.RefObject<HTMLElement | null>;
    /** Optional — called on every mousemove with normalized coords (null on leave). */
    onCrosshairUpdate?: (norm: {
        nx: number;
        ny: number;
    } | null) => void;
}
/**
 * Compose zoom/pan + drawing mouse handlers for a labeling canvas capture layer.
 *
 * Returns:
 * - `mouseHandlers` — spread into the capture div
 * - `cursor` — current CSS cursor (grabbing | grab | drawingCursor)
 * - `isHoveringEditable` — whether the cursor is over a drawing object in canPan mode
 *
 * Logic mirrors platform ImageDetailCanvas + edge BBoxCanvas mouse composition:
 * - Middle mouse + zoomed → pan regardless of tool
 * - canPan (tool='cursor' && zoom>1) + click on object → drawing (select/move/resize)
 * - canPan + click on empty → pan
 * - else → drawing
 */
declare function useCanvasMouse({ tool, zoom, hitTestEditable, drawingObjects, drawingBindings, drawingCursor, startPan, movePan, endPan, isZoomPanning, pan, containerRef, onCrosshairUpdate, }: UseCanvasMouseConfig): {
    mouseHandlers: {
        onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
        onMouseMove: (event: React.MouseEvent<HTMLDivElement>) => void;
        onMouseUp: (event: React.MouseEvent<HTMLDivElement>) => void;
        onMouseLeave: () => void;
    };
    cursor: React.CSSProperties['cursor'];
    isHoveringEditable: boolean;
};

interface ElementSize {
    width: number;
    height: number;
}
interface UseElementSizeOptions {
    /** Minimum width to enforce when reporting. Useful for narrow grid cells. */
    minWidth?: number;
    /** Minimum height to enforce when reporting. */
    minHeight?: number;
    /** Also re-measure on `window.resize`. Default: true. */
    watchWindowResize?: boolean;
}
/**
 * Tracks an element's CSS-pixel size via `ResizeObserver` (+ optional window
 * resize listener fallback). Used by responsive chart wrappers / canvas hosts.
 *
 * Returns `{ 0, 0 }` until first measurement — caller should guard rendering
 * (`size.width > 0 && size.height > 0`).
 */
declare function useElementSize(ref: RefObject<HTMLElement | null>, options?: UseElementSizeOptions): ElementSize;

interface ZoomInvariantRendererCtx {
    /** Container width in CSS pixels (resolved from prop or self-measured). */
    cw: number;
    /** Container height in CSS pixels. */
    ch: number;
    /** Whether container size is known (cw, ch > 0). */
    uniform: boolean;
    /** Current zoom level (default 1). */
    z: number;
    /** Convert px → viewBox-unit accounting for zoom. */
    s: (px: number) => number;
}
interface UseZoomInvariantRendererOptions {
    /** Element ref to measure. */
    ref: RefObject<Element | null>;
    /** Explicit container width (overrides measurement). */
    containerWidth?: number;
    /** Explicit container height (overrides measurement). */
    containerHeight?: number;
    /** Current zoom level. Default 1. */
    zoom?: number;
}
/**
 * Computes zoom-invariant rendering context for SVG overlays sitting on top of
 * a zoomable image (drawing-layer, measurement tools, annotation editors).
 *
 * Resolution priority for cw/ch: explicit prop > self-measured via
 * `ResizeObserver`. `uniform` is true only when both dimensions are known.
 *
 * `s(px)` converts a pixel value (stroke width, handle size, label font) into
 * a viewBox-unit value scaled inversely by zoom, so the rendered size stays
 * constant on screen regardless of zoom level.
 */
declare function useZoomInvariantRenderer({ ref, containerWidth, containerHeight, zoom, }: UseZoomInvariantRendererOptions): ZoomInvariantRendererCtx;

interface NormalizedCoord {
    nx: number;
    ny: number;
}
/**
 * Convert a pointer event's client coordinates to normalized [0..1] coords
 * within the given element's bounding rect. Returns `null` when the element
 * isn't mounted.
 *
 * Used by canvas / image hooks (`useCanvasMouse`, `useDrawingCanvas`) so the
 * conversion stays consistent.
 */
declare function getNormalizedCoord(ref: RefObject<HTMLElement | null>, event: {
    clientX: number;
    clientY: number;
}, options?: {
    clamp?: boolean;
}): NormalizedCoord | null;

type ButtonVariant = 'solid' | 'secondary' | 'accent' | 'ghost';
type LegacyButtonVariant = 'primary' | 'ghost' | 'accent';
type ButtonSize = 'sm' | 'md' | 'lg';
type ButtonTone = 'default' | 'danger';
type ButtonProps = React__default.ComponentPropsWithoutRef<'button'> & {
    variant?: ButtonVariant;
    $variant?: LegacyButtonVariant;
    size?: ButtonSize;
    tone?: ButtonTone;
    leadingIcon?: React__default.ReactNode;
    trailingIcon?: React__default.ReactNode;
    'data-ig-component'?: string;
    'data-ig-slot'?: string;
    'data-ig-layer'?: string;
};
declare const buttonPadding: {
    readonly sm: "var(--ig-space-3) var(--ig-space-6)";
    readonly md: "var(--ig-space-4) var(--ig-space-8)";
    readonly lg: "var(--ig-space-5) var(--ig-space-10)";
};
declare function normalizeVariant(variant?: ButtonVariant, legacyVariant?: LegacyButtonVariant): ButtonVariant;

declare const Button: React__default.ForwardRefExoticComponent<Omit<React__default.DetailedHTMLProps<React__default.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, "ref"> & {
    variant?: ButtonVariant;
    $variant?: LegacyButtonVariant;
    size?: ButtonSize;
    tone?: ButtonTone;
    leadingIcon?: React__default.ReactNode;
    trailingIcon?: React__default.ReactNode;
    'data-ig-component'?: string;
    'data-ig-slot'?: string;
    'data-ig-layer'?: string;
} & React__default.RefAttributes<HTMLButtonElement>>;

declare const IconButton: React__default.ForwardRefExoticComponent<Omit<React__default.DetailedHTMLProps<React__default.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, "ref"> & {
    variant?: ButtonVariant;
    $variant?: LegacyButtonVariant;
    size?: ButtonSize;
    tone?: ButtonTone;
    leadingIcon?: React__default.ReactNode;
    trailingIcon?: React__default.ReactNode;
    'data-ig-component'?: string;
    'data-ig-slot'?: string;
    'data-ig-layer'?: string;
} & React__default.RefAttributes<HTMLButtonElement>>;

type TextButtonTone = 'accent' | 'muted';
type TextButtonSize = 'xs' | 'sm';
interface TextButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    tone?: TextButtonTone;
    size?: TextButtonSize;
    iconLeading?: ReactNode;
    iconTrailing?: ReactNode;
    children: ReactNode;
}
/**
 * Borderless text button used for inline actions (link-like CTAs, toggle labels).
 * Hover underlines; tone selects accent vs muted color. Use Button or IconButton
 * when you need a real chrome surface or icon-only target.
 */
declare const TextButton: React$1.ForwardRefExoticComponent<TextButtonProps & React$1.RefAttributes<HTMLButtonElement>>;

interface DragHandleProps {
    ariaLabel?: string;
    title?: string;
    onPointerDown?: MouseEventHandler<HTMLButtonElement>;
    /** Spread caller's dnd-kit `attributes` here. */
    buttonProps?: Record<string, unknown>;
    className?: string;
}
declare function DragHandle({ ariaLabel, title, onPointerDown, buttonProps, className, }: DragHandleProps): react_jsx_runtime.JSX.Element;

type TextFieldSize = 'sm' | 'md' | 'lg';
interface TextFieldProps extends Omit<React__default.InputHTMLAttributes<HTMLInputElement>, 'size'> {
    size?: TextFieldSize;
}
declare const TextField: React__default.ForwardRefExoticComponent<TextFieldProps & React__default.RefAttributes<HTMLInputElement>>;
declare const TextareaField: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.TextareaHTMLAttributes<HTMLTextAreaElement>, HTMLTextAreaElement>, never>> & string;
declare const PasswordField: React__default.ForwardRefExoticComponent<TextFieldProps & React__default.RefAttributes<HTMLInputElement>>;

type TextareaVariant = 'default' | 'monospace';
interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
    variant?: TextareaVariant;
    minHeight?: number;
}
/**
 * Multi-line text field. Use `variant="monospace"` for token / code / IP-list inputs.
 * `minHeight` (px) controls the initial vertical room — user can still drag-resize.
 */
declare const Textarea: React$1.ForwardRefExoticComponent<TextareaProps & React$1.RefAttributes<HTMLTextAreaElement>>;

type ColorInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type'>;
/**
 * Square (40x40) native `<input type="color">` with webkit chrome overrides.
 * Standard input event/value semantics — caller reads `e.target.value` (#rrggbb).
 */
declare const ColorInput: React$1.ForwardRefExoticComponent<ColorInputProps & React$1.RefAttributes<HTMLInputElement>>;

type ResizeHandleOrientation = 'vertical' | 'horizontal';
interface ResizeHandleProps extends Omit<HTMLAttributes<HTMLDivElement>, 'role' | 'aria-orientation'> {
    orientation?: ResizeHandleOrientation;
}
/**
 * Drag-to-resize separator handle. The 8px target spans the parent's cross-axis;
 * the narrow visual strip (via ::after) is centered with insets.
 * Caller wires onMouseDown to drive the resize math.
 */
declare const ResizeHandle: React$1.ForwardRefExoticComponent<ResizeHandleProps & React$1.RefAttributes<HTMLDivElement>>;

type DropZoneVariant = 'outlined' | 'filled';
interface DropZoneProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
    variant?: DropZoneVariant;
    active?: boolean;
    disabled?: boolean;
    children: ReactNode;
}
/**
 * Universal drop target surface. Caller wires the drag event handlers and
 * decides what to do with `dataTransfer`; this component only renders the
 * visual chrome (border / background / active highlight / disabled state).
 *
 * `variant="outlined"` for file-upload boxes (dashed, large). `variant="filled"`
 * for slim inline drop targets (solid, compact).
 */
declare const DropZone: React$1.ForwardRefExoticComponent<DropZoneProps & React$1.RefAttributes<HTMLDivElement>>;

interface SearchFieldProps extends Omit<React__default.InputHTMLAttributes<HTMLInputElement>, 'type' | 'size'> {
    onClear?: () => void;
    size?: 'sm' | 'md';
}
declare function SearchField({ onClear, size, value, ...rest }: SearchFieldProps): react_jsx_runtime.JSX.Element;

interface InputAdornmentProps extends React__default.HTMLAttributes<HTMLDivElement> {
    side: 'left' | 'right';
    inset?: string;
    stretchY?: boolean;
    children: React__default.ReactNode;
}
declare function InputAdornment({ side, inset, stretchY, children, ...rest }: InputAdornmentProps): react_jsx_runtime.JSX.Element;

interface PopoverTriggerFieldProps {
    /** Whether the popover is currently open. */
    open: boolean;
    /** Called when the popover should open/close (click outside, ESC, programmatic). */
    onOpenChange: (open: boolean) => void;
    /** Trigger element (rendered inline). Should wire its own onClick to call onOpenChange. */
    trigger: React__default.ReactNode;
    /** Popover menu content (rendered in a portal under document.body). */
    children: React__default.ReactNode;
    /** ARIA role for the menu container (e.g. 'listbox' / 'menu'). */
    menuRole?: string;
    className?: string;
    style?: React__default.CSSProperties;
}
/**
 * Trigger + portal popover with viewport-bounded positioning.
 *
 * Uses `DropdownMenu` styled (width matches trigger). For free-width popovers
 * (e.g. date picker with library-defined width) use a different primitive.
 */
declare function PopoverTriggerField({ open, onOpenChange, trigger, children, menuRole, className, style, }: PopoverTriggerFieldProps): react_jsx_runtime.JSX.Element;

interface FloatingPanelFieldProps {
    /** Whether the panel is currently open. */
    open: boolean;
    /** Called when the panel should close (click outside, ESC). */
    onOpenChange: (open: boolean) => void;
    /** Trigger element (rendered inline). Wire its onClick to call onOpenChange. */
    trigger: React__default.ReactNode;
    /**
     * Render prop. Receives a position style (`position: 'fixed'`, `top`, `left`)
     * and a `ref` callback for the panel root. Caller applies them to its own
     * styled container.
     */
    children: (props: {
        style: React__default.CSSProperties;
        ref: (node: HTMLDivElement | null) => void;
    }) => React__default.ReactNode;
    /** Estimated panel height (px). Used for above/below decision before the panel is actually measured. */
    estimatedHeight?: number;
    /** Pixel gap between trigger and panel. Default 6. */
    gap?: number;
    className?: string;
    style?: React__default.CSSProperties;
}
/**
 * Trigger + portal panel with viewport-bounded positioning, **no width
 * enforcement**. For dropdowns whose contents own their own width (date picker,
 * color picker, library widgets). Counterpart of `PopoverTriggerField` which
 * matches trigger width (menu / select pattern).
 */
declare function FloatingPanelField({ open, onOpenChange, trigger, children, estimatedHeight, gap, className, style, }: FloatingPanelFieldProps): react_jsx_runtime.JSX.Element;

interface NumberFieldProps {
    value: number;
    onChange: (v: number) => void;
    min?: number;
    max?: number;
    step?: number;
    disabled?: boolean;
    placeholder?: string;
    format?: (v: number) => string;
    parse?: (s: string) => number;
    className?: string;
    id?: string;
    name?: string;
    required?: boolean;
    autoFocus?: boolean;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    title?: string;
}
declare function NumberField({ value, onChange, min, max, step, disabled, placeholder, format, parse, className, id, name, required, autoFocus, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledBy, title, }: NumberFieldProps): react_jsx_runtime.JSX.Element;

interface MentionCandidate {
    id: string;
    name: string;
    secondary?: string;
}
interface MentionTextareaProps {
    value: string;
    onChange: (value: string) => void;
    candidates: MentionCandidate[];
    onSubmit?: (text: string, mentionIds: string[]) => void;
    placeholder?: string;
    maxLength?: number;
    disabled?: boolean;
    className?: string;
    triggerChar?: string;
    'aria-label'?: string;
}
declare function MentionTextarea({ value, onChange, candidates, onSubmit, placeholder, maxLength, disabled, className, triggerChar, 'aria-label': ariaLabel, }: MentionTextareaProps): react_jsx_runtime.JSX.Element;

declare const Checkbox: React__default.ForwardRefExoticComponent<React__default.InputHTMLAttributes<HTMLInputElement> & {
    label?: React__default.ReactNode;
    indeterminate?: boolean;
    'data-ig-component'?: string;
    'data-ig-label'?: string;
    'data-ig-slot'?: string;
} & React__default.RefAttributes<HTMLInputElement>>;
declare const Radio: React__default.ForwardRefExoticComponent<React__default.InputHTMLAttributes<HTMLInputElement> & {
    label?: React__default.ReactNode;
    'data-ig-component'?: string;
    'data-ig-label'?: string;
    'data-ig-slot'?: string;
} & React__default.RefAttributes<HTMLInputElement>>;
declare const Switch: React__default.ForwardRefExoticComponent<Omit<React__default.InputHTMLAttributes<HTMLInputElement>, "type"> & {
    label?: React__default.ReactNode;
    'data-ig-component'?: string;
    'data-ig-label'?: string;
    'data-ig-slot'?: string;
} & React__default.RefAttributes<HTMLInputElement>>;

declare function FileInput({ onFiles, accept, multiple, label, }: {
    onFiles: (files: File[]) => void;
    accept?: string;
    multiple?: boolean;
    label?: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

type SelectFieldProps = React__default.SelectHTMLAttributes<HTMLSelectElement>;
declare function SelectField({ children, value, defaultValue, onChange, disabled, className, style, name, id, required, autoFocus, ...props }: SelectFieldProps): react_jsx_runtime.JSX.Element;

interface DropdownOption {
    value: string;
    label: string;
    description?: string;
}

declare function DropdownSelect({ value, options, onChange, disabled, }: {
    value: string;
    options: DropdownOption[];
    onChange: (value: string) => void;
    disabled?: boolean;
}): react_jsx_runtime.JSX.Element;

interface UploadDropzoneProps {
    accept?: string;
    multiple?: boolean;
    onFiles: (files: File[]) => void;
    disabled?: boolean;
    children?: React__default.ReactNode;
    className?: string;
}
declare function UploadDropzone({ accept, multiple, onFiles, disabled, children, className, }: UploadDropzoneProps): react_jsx_runtime.JSX.Element;

interface CopyButtonProps {
    value: string;
    children?: React__default.ReactNode;
    copiedLabel?: string;
    size?: 'sm' | 'md';
    className?: string;
}
declare function CopyButton({ value, children, copiedLabel, size, className, }: CopyButtonProps): react_jsx_runtime.JSX.Element;

interface ModeSwitcherOption {
    value: string;
    label: string;
    icon?: React__default.ReactNode;
}
interface ModeSwitcherProps {
    options: ModeSwitcherOption[];
    value: string;
    onChange: (value: string) => void;
    size?: 'sm' | 'md';
    shape?: 'rounded' | 'pill';
    iconOnly?: boolean;
    className?: string;
}
declare function ModeSwitcher({ options, value, onChange, size, shape, iconOnly, className, }: ModeSwitcherProps): react_jsx_runtime.JSX.Element;
declare const SegmentedControl: typeof ModeSwitcher;
type SegmentedControlOption = ModeSwitcherOption;
type SegmentedControlProps = ModeSwitcherProps;

interface FieldRowProps {
    label: string;
    htmlFor?: string;
    hint?: string;
    children: React__default.ReactNode;
}
declare function FieldRow({ label, htmlFor, hint, children }: FieldRowProps): react_jsx_runtime.JSX.Element;
interface FormFieldProps {
    label: string;
    htmlFor?: string;
    children: React__default.ReactNode;
    className?: string;
}
declare function FormField({ label, htmlFor, children, className }: FormFieldProps): react_jsx_runtime.JSX.Element;

interface FilterBarLayoutProps {
    onClear?: () => void;
    clearLabel?: string;
    children: React__default.ReactNode;
    className?: string;
}
declare function FilterBarLayout({ onClear, clearLabel, children, className }: FilterBarLayoutProps): react_jsx_runtime.JSX.Element;

interface FilterPopoverTriggerProps {
    label: React__default.ReactNode;
    icon?: React__default.ReactNode;
    active?: boolean;
    iconOnly?: boolean;
    panel: React__default.ReactNode;
    defaultOpen?: boolean;
    panelWidth?: number;
    panelMinWidth?: number;
    className?: string;
}
declare function FilterPopoverTrigger({ label, icon, active, iconOnly, panel, defaultOpen, panelWidth, panelMinWidth, className, }: FilterPopoverTriggerProps): react_jsx_runtime.JSX.Element;

interface FilterChipItem {
    id: string;
    label: string;
    count?: number;
}
interface FilterChipRowProps {
    /** uppercase 라벨 (왼쪽). 기본 'Filter'. */
    label?: string;
    items: FilterChipItem[];
    /** 빈 set 이면 모두 active 로 간주 (toggle 로 explicitly off 되기 전엔 전체 노출). */
    activeIds: Set<string>;
    loading?: boolean;
    loadingText?: string;
    emptyText?: string;
    onToggle?: (id: string) => void;
}
/**
 * Horizontal toggle chip row with label + per-item count badge.
 * Empty activeIds set 은 "전체 활성" 으로 해석 (toggle 시작 전 default state).
 * Dataset / class / member / 일반 다중 선택 필터링에 generic.
 */
declare function FilterChipRow({ label, items, activeIds, loading, loadingText, emptyText, onToggle, }: FilterChipRowProps): react_jsx_runtime.JSX.Element;

interface ColorChipProps {
    checked: boolean;
    label: ReactNode;
    color?: string;
    onChange: (checked: boolean) => void;
    className?: string;
}
declare function ColorChip({ checked, label, color, onChange, className }: ColorChipProps): react_jsx_runtime.JSX.Element;

interface ChipTabsItem extends FormatPatternTabItem {
    id: string;
}
interface ChipTabsProps {
    items: ChipTabsItem[];
    currentId: string;
    onSelect: (item: ChipTabsItem) => void;
    className?: string;
}
declare function ChipTabs({ items, currentId, onSelect, className }: ChipTabsProps): react_jsx_runtime.JSX.Element | null;

interface MobileDropdownOption {
    id: string;
    name: string;
}
interface MobileDropdownProps {
    options: MobileDropdownOption[];
    currentId?: string;
    loading?: boolean;
    open: boolean;
    onToggle: (open: boolean) => void;
    onSelect: (id: string) => void;
    placeholder?: string;
}
/**
 * Mobile-only full-width dropdown — sticky-blur glass dropdown surface.
 * Desktop 환경에선 DropdownSelect / DropdownLayout 을 사용.
 */
declare function MobileDropdown({ options, currentId, loading, open, onToggle, onSelect, placeholder, }: MobileDropdownProps): react_jsx_runtime.JSX.Element;

interface ToolbarShellAction {
    key: string;
    /** Tooltip + aria-label. */
    title: string;
    icon: React__default.ReactNode;
    /** Active toggle state (mode buttons). */
    active?: boolean;
    disabled?: boolean;
    /** Danger style (delete 등). */
    danger?: boolean;
    onClick: (event: React__default.MouseEvent<HTMLButtonElement>) => void;
    /** Optional className (e.g. mobile-only show/hide). */
    className?: string;
}
interface ToolbarShellProps {
    /** Action 버튼 배열. 문자열 `'separator'` 가 섞여 있으면 구분자 표시. */
    actions: Array<ToolbarShellAction | 'separator'>;
    /** Trailing slot — actions 뒤. 가로 placement 면 오른쪽 끝, 세로면 아래 끝. */
    trailing?: React__default.ReactNode;
    /** Toolbar 배치 방향. 모두 inline flex (sibling 와 overlap 없음).
     *  - `'bottom'` (default) / `'top'`: 가로 row.
     *  - `'left'` / `'right'`: 세로 column. */
    placement?: 'bottom' | 'top' | 'left' | 'right';
    /** 버튼 사이즈. default `'md'` (40px) / `'sm'` (36px). */
    size?: 'sm' | 'md';
    className?: string;
    /** ARIA toolbar label — 복수 toolbar 시 unique 보장. */
    ariaLabel?: string;
}
/**
 * Generic toolbar shell — actions array + optional trailing slot + 4-placement.
 * Canvas / image-viewer / 일반 toolbar 어디서나 재사용 가능한 작업 모음 컨테이너.
 */
declare function ToolbarShell({ actions, trailing, placement, size, className, ariaLabel, }: ToolbarShellProps): react_jsx_runtime.JSX.Element;

interface DatePickerProps {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
}
declare function DatePickerField({ value, onChange, placeholder, disabled, className, }: DatePickerProps): react_jsx_runtime.JSX.Element;

type DateRangePickerValue = Date | DateRange | undefined;
interface DateRangePickerPreset {
    id: string;
    label: string;
    resolve: () => DateRangePickerValue;
}
interface DateRangePickerProps {
    /** 'single' = 단일 날짜 선택, 'range' = 범위 선택 (시작/끝 두 클릭). */
    mode: 'single' | 'range';
    value: DateRangePickerValue;
    onChange: (next: DateRangePickerValue) => void;
    /** Preset 버튼 (Today / Last 7 days / This month 등). 없으면 미렌더. */
    presets?: DateRangePickerPreset[];
    /** Apply 버튼 onClick. 없으면 Apply 버튼 미렌더. */
    onApply?: () => void;
    /** Reset 버튼 onClick. 없으면 Reset 버튼 미렌더. */
    onReset?: () => void;
    /** Popover 헤더 제목. */
    title?: ReactNode;
    /** Popover 헤더 부제. */
    subtitle?: ReactNode;
    /** Calendar 아래 현재 선택 요약 (예: "Apr 1 — Apr 7"). */
    summaryLabel?: ReactNode;
    /** Footer 안내 (예: "Saved per user"). */
    footerHint?: ReactNode;
    className?: string;
}
/**
 * Date / Date-range picker with preset buttons + Apply / Reset footer.
 * MenuPopover surface 안에 calendar + presets + summary + footer 를 배치.
 * Calendar 는 `react-day-picker` 의 DayPicker (단일/범위 모드).
 *
 * Caller 가 외부에서 conditional render 로 visibility 제어 (popover 가 항상 보이는
 * 위치에 absolute 로 배치되므로). 단일 input 형태가 필요하면 DatePickerField 사용.
 */
declare function DateRangePicker({ mode, value, onChange, presets, onApply, onReset, title, subtitle, summaryLabel, footerHint, className, }: DateRangePickerProps): react_jsx_runtime.JSX.Element;

type RadioCardGroupOrientation = 'vertical' | 'horizontal';
interface RadioCardGroupOption {
    value: string;
    label: string;
    disabled?: boolean;
}
interface RadioCardGroupProps {
    options: RadioCardGroupOption[];
    value: string;
    onChange: (value: string) => void;
    /** 옵션 정렬 방향 (default vertical) */
    orientation?: RadioCardGroupOrientation;
    className?: string;
}
declare function RadioCardGroup({ options, value, onChange, orientation, className }: RadioCardGroupProps): react_jsx_runtime.JSX.Element;

declare const SmallText: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;
declare const StatusPill: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $tone?: StatusTone;
    tone?: StatusTone;
}>> & string;

declare const badgeTone: {
    readonly neutral: "var(--ig-color-badge-neutral)";
    readonly accent: "var(--ig-color-badge-accent)";
    readonly success: "var(--ig-color-badge-success)";
    readonly warning: "var(--ig-color-badge-warning)";
    readonly danger: "var(--ig-color-badge-danger)";
};
declare const Badge: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $tone?: keyof typeof badgeTone;
}>> & string;

declare const Chip: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "$tone"> & {
    $tone?: "accent" | "success" | "warning" | "danger" | "neutral";
}, "ref"> & {
    ref?: ((instance: HTMLSpanElement | null) => void | React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React$1.RefObject<HTMLSpanElement> | null | undefined;
}, never>> & string;

declare function Avatar({ src, alt, initials, size, }: {
    src?: string;
    alt?: string;
    initials?: string;
    size?: number;
}): react_jsx_runtime.JSX.Element;

declare const NotificationBubble: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $tone: "accent" | "danger";
}>> & string;
declare function NotificationBadge({ children, value, hidden, tone, className, style, }: {
    children: React__default.ReactNode;
    value?: React__default.ReactNode;
    hidden?: boolean;
    tone?: 'accent' | 'danger';
    className?: string;
    style?: React__default.CSSProperties;
}): react_jsx_runtime.JSX.Element;

declare const ProgressTrack: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ProgressFill: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    $value: number;
    $active: boolean;
}>> & string;
declare function ProgressBar({ value }: {
    value: number;
}): react_jsx_runtime.JSX.Element;

interface ProgressSegment {
    label: string;
    value: number;
    color: string;
}
interface SegmentedProgressBarProps {
    segments: ProgressSegment[];
    total?: number;
    showLegend?: boolean;
    className?: string;
}
/**
 * Multi-segment progress bar with optional legend.
 * 각 세그먼트는 색 + 라벨 + 값. total 미지정 시 segments 의 value 합산.
 * Labeling progress / 분석 단계별 진척 / 분포 시각화 등에 generic.
 */
declare function SegmentedProgressBar({ segments, total, showLegend, className, }: SegmentedProgressBarProps): react_jsx_runtime.JSX.Element;

declare const Skeleton: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    $height?: string;
}>> & string;

declare const Alert: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    $tone?: keyof typeof alertToneStyles;
}>> & string;
declare const InlineMessage: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "$tone"> & {
    $tone?: keyof typeof alertToneStyles;
}, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React$1.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;

declare const sizeMap: {
    readonly sm: 14;
    readonly md: 18;
    readonly lg: 24;
};
declare const toneColorMap: {
    readonly accent: "var(--ig-color-accent)";
    readonly white: "var(--ig-color-text-primary)";
    readonly muted: "var(--ig-color-text-soft)";
};
type SpinnerSize = keyof typeof sizeMap | number;
type SpinnerTone = keyof typeof toneColorMap;
interface SpinnerProps extends Omit<React__default.HTMLAttributes<HTMLSpanElement>, 'children'> {
    /** Spinner 크기. sm=14px (icon-sm), md=18px (icon-lg), lg=24px (icon-3xl), 또는 직접 pixel 값 */
    size?: SpinnerSize;
    /** 색상 tone. accent=브랜드 색, white=텍스트 primary, muted=텍스트 soft */
    tone?: SpinnerTone;
}
declare function Spinner({ size, tone, 'aria-label': ariaLabel, ...rest }: SpinnerProps): react_jsx_runtime.JSX.Element;

type ToastTone = keyof typeof alertToneStyles;
interface ToastAction {
    label: string;
    onClick: () => void;
}
interface ToastItem {
    id: string;
    message: React__default.ReactNode;
    tone?: ToastTone;
    duration?: number;
    action?: ToastAction;
}
type ToastFn = (message: React__default.ReactNode, opts?: {
    tone?: ToastTone;
    duration?: number;
    action?: ToastAction;
}) => void;
declare function useToast(): ToastFn;
declare function ToastProvider({ children }: {
    children: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

interface SelectionActionBarProps {
    selectedCount: number;
    totalCount?: number;
    onClearSelection: () => void;
    onSelectAll?: () => void;
    selectAllLabel?: string;
    actions?: React__default.ReactNode;
    className?: string;
}
declare function SelectionActionBar({ selectedCount, totalCount, onClearSelection, onSelectAll, selectAllLabel, actions, className, }: SelectionActionBarProps): react_jsx_runtime.JSX.Element | null;

interface EmptyStateProps {
    icon?: React__default.ReactNode;
    title?: string;
    description?: string;
    action?: {
        label: string;
        onClick: () => void;
    };
    className?: string;
    children?: React__default.ReactNode;
    'data-ig-component'?: string;
    'data-ig-slot'?: string;
}
declare function EmptyState({ icon, title, description, action, className, children, 'data-ig-component': componentHint, 'data-ig-slot': slotHint, }: EmptyStateProps): react_jsx_runtime.JSX.Element;

interface DefaultErrorFallbackProps {
    error: unknown;
    resetErrorBoundary?: () => void;
}
declare function DefaultErrorFallback({ error, resetErrorBoundary }: DefaultErrorFallbackProps): react_jsx_runtime.JSX.Element;
interface ErrorBoundaryProps {
    children: ReactNode;
    fallback?: ReactNode | ((error: Error, reset: () => void) => ReactNode);
    onError?: (error: Error, info: ErrorInfo) => void;
}
interface ErrorBoundaryState {
    error: Error | null;
}
declare class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
    state: ErrorBoundaryState;
    static getDerivedStateFromError(error: Error): ErrorBoundaryState;
    componentDidCatch(error: Error, info: ErrorInfo): void;
    reset: () => void;
    render(): ReactNode;
}

type StepStatus = 'pending' | 'running' | 'done' | 'error';
interface StepItem {
    label: string;
    status: StepStatus;
}
interface StepIndicatorProps {
    items: StepItem[];
    className?: string;
}
declare function StepIndicator({ items, className }: StepIndicatorProps): react_jsx_runtime.JSX.Element;

interface GroupCountBadgeProps {
    count: number;
    size?: 'sm' | 'md';
    formatLarge?: boolean;
    className?: string;
}
declare function GroupCountBadge({ count, size, formatLarge, className }: GroupCountBadgeProps): react_jsx_runtime.JSX.Element | null;

type MediaOverlayVariant = 'archived' | 'processing';
interface MediaOverlayProps {
    variant: MediaOverlayVariant;
    label?: string;
    icon?: React__default.ReactNode;
    className?: string;
}
declare function MediaOverlay({ variant, label, icon, className }: MediaOverlayProps): react_jsx_runtime.JSX.Element;

interface TooltipCardProps extends React__default.HTMLAttributes<HTMLDivElement> {
    children: React__default.ReactNode;
}
declare function TooltipCard({ children, ...rest }: TooltipCardProps): react_jsx_runtime.JSX.Element;

interface StateChipStyle {
    bg: string;
    color: string;
}
interface StateChipProps<S extends string> {
    state: S;
    label: React.ReactNode;
    stateStyles: Record<S, StateChipStyle>;
    showDot?: boolean;
    collapseUntilHover?: boolean;
    className?: string;
    'aria-label'?: string;
}
declare function StateChip<S extends string>({ state, label, stateStyles, showDot, collapseUntilHover, className, 'aria-label': ariaLabel, }: StateChipProps<S>): react_jsx_runtime.JSX.Element;

declare function Tabs({ items, value, onChange, variant, className, style, }: {
    items: Array<{
        value: string;
        label: string;
    }>;
    value: string;
    onChange: (value: string) => void;
    variant?: 'pill' | 'underline';
    className?: string;
    style?: React__default.CSSProperties;
}): react_jsx_runtime.JSX.Element;
declare const TabsNav: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;

type VerticalTabsRadius = 'xs' | 'sm' | 'md' | 'lg';

type VerticalTabsItem = {
    value: string;
    label: React__default.ReactNode;
    badge?: React__default.ReactNode;
    icon?: React__default.ReactNode;
    disabled?: boolean;
};
declare function VerticalTabs({ items, value, onChange, radius, className, style, }: {
    items: VerticalTabsItem[];
    value: string;
    onChange: (value: string) => void;
    radius?: VerticalTabsRadius;
    className?: string;
    style?: React__default.CSSProperties;
}): react_jsx_runtime.JSX.Element;

declare function Breadcrumbs({ items, ariaLabel, }: {
    items: Array<{
        label: string;
        href?: string;
    }>;
    /** Override for landmark uniqueness when multiple breadcrumbs render on the same page */
    ariaLabel?: string;
}): react_jsx_runtime.JSX.Element;

declare function Pagination({ page, totalPages, onChange, }: {
    page: number;
    totalPages: number;
    onChange: (page: number) => void;
}): react_jsx_runtime.JSX.Element;

declare function Stepper({ steps, activeStep, }: {
    steps: string[];
    activeStep: number;
}): react_jsx_runtime.JSX.Element;

interface MobileNavShellItem {
    key: string;
    label: string;
    icon: ReactNode;
    active?: boolean;
    /** When provided and > 0, shown as a red badge at row end. */
    badge?: number;
    onClick: (event: MouseEvent<HTMLButtonElement>) => void;
}
interface MobileNavShellProps {
    open: boolean;
    onOpen: () => void;
    onClose: () => void;
    /** App header brand element (left of title in fixed top header). */
    appHeaderBrand: ReactNode;
    /** App header title text shown beside brand. */
    appHeaderTitle?: ReactNode;
    /** App header hamburger icon (default: lucide Menu). */
    hamburgerIcon?: ReactNode;
    /** Drawer header brand element (shown above project title button). */
    drawerBrand: ReactNode;
    /** Drawer title button label — typically current project name. */
    drawerTitle?: string;
    /** Drawer title icon (folder etc) appended after label. */
    drawerTitleIcon?: ReactNode;
    /** Click handler for drawer title row — typically opens project modal. */
    onDrawerTitleClick?: () => void;
    /** Close icon (default: lucide X). */
    closeIcon?: ReactNode;
    /** Main navigation rows. */
    mainItems: MobileNavShellItem[];
    /** Bottom action rows (notice / comment / settings / user etc). */
    bottomItems: MobileNavShellItem[];
    /** aria-label for the main nav section. */
    navLabel?: string;
    className?: string;
}
/**
 * Mobile app shell: fixed top header with hamburger + drop-down drawer with
 * main nav and bottom actions. Platform 의 SidebarShell 의 mobile counterpart.
 *
 * Items are configured via `mainItems` / `bottomItems` props — same pattern
 * as `SidebarShell` (icon + label + onClick + optional active/badge).
 */
declare function MobileNavShell({ open, onOpen, onClose, appHeaderBrand, appHeaderTitle, hamburgerIcon, drawerBrand, drawerTitle, drawerTitleIcon, onDrawerTitleClick, closeIcon, mainItems, bottomItems, navLabel, className, }: MobileNavShellProps): react_jsx_runtime.JSX.Element;

interface IndexedNavigationProps {
    index: number;
    total: number;
    onChange: (next: number) => void;
    prevLabel?: string;
    nextLabel?: string;
    className?: string;
}
/**
 * Prev/next 화살표 + "현재/전체" 카운터. 단일 항목일 때는 숨김 (total <= 1).
 * Bbox / image / step / page 등 인덱스 기반 순차 탐색에 generic.
 */
declare function IndexedNavigation({ index, total, onChange, prevLabel, nextLabel, className, }: IndexedNavigationProps): react_jsx_runtime.JSX.Element | null;

interface MobileBottomToolbarAction {
    key: string;
    label: string;
    icon: ReactNode;
    active?: boolean;
    disabled?: boolean;
    title?: string;
    onClick?: () => void;
}
interface MobileBottomToolbarProps {
    actions: MobileBottomToolbarAction[];
    extraSlot?: ReactNode;
}
declare function MobileBottomToolbar({ actions, extraSlot }: MobileBottomToolbarProps): react_jsx_runtime.JSX.Element;

declare const ModalBackdrop: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ModalCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const CompactModalCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React$1.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const ModalHeader: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ModalTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const ModalActions: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Drawer: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLElement>, HTMLElement>, {
    $side?: "left" | "right";
}>> & string;

declare const PopoverCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Menu: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
interface MenuPopoverProps extends React__default.HTMLAttributes<HTMLDivElement> {
    anchor?: {
        top: number;
        left: number;
    };
}
declare const MenuPopover: React__default.ForwardRefExoticComponent<MenuPopoverProps & React__default.RefAttributes<HTMLDivElement>>;
declare const TooltipBubble: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const HoverCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | React__default.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React__default.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React__default.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;

declare function DialogCloseButton({ 'aria-label': ariaLabel, title, children, ...props }: React__default.ComponentPropsWithoutRef<typeof IconButton>): react_jsx_runtime.JSX.Element;

declare function DialogShell({ title, description, children, actions, onClose, width, height, }: {
    title: React__default.ReactNode;
    description?: React__default.ReactNode;
    children?: React__default.ReactNode;
    actions?: React__default.ReactNode;
    onClose?: () => void;
    width?: string | number;
    height?: string | number;
}): react_jsx_runtime.JSX.Element;
declare function ConfirmDialog({ title, description, confirmLabel, cancelLabel, onConfirm, onCancel, confirmVariant, danger, }: {
    title: React__default.ReactNode;
    description: React__default.ReactNode;
    confirmLabel?: React__default.ReactNode;
    cancelLabel?: React__default.ReactNode;
    onConfirm: () => void;
    onCancel: () => void;
    confirmVariant?: ButtonVariant;
    danger?: boolean;
}): react_jsx_runtime.JSX.Element;

interface TwoColumnDialogProps {
    title: React__default.ReactNode;
    sidebar?: React__default.ReactNode;
    children: React__default.ReactNode;
    onClose: () => void;
    width?: string;
    /** 고정 높이. 지정 시 dialog 가 항상 같은 높이 (content 와 무관). 미지정 시 max-height fallback. */
    height?: string;
    maxHeight?: string;
    sidebarWidth?: string;
}
declare function TwoColumnDialog({ title, sidebar, children, onClose, width, height, maxHeight, sidebarWidth, }: TwoColumnDialogProps): React__default.ReactPortal | null;

/** click-outside 처리를 위한 투명 backdrop */
declare const ContextMenuBackdrop: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
/** cursor 위치에 fixed 배치되는 메뉴 컨테이너 */
declare const ContextMenuList: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, Omit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React$1.RefObject<HTMLDivElement> | null | undefined;
}>, {
    $x: number;
    $y: number;
}>, {
    $x: number;
    $y: number;
}>> & string;
/** 하위 메뉴(서브메뉴)를 감싸는 wrapper — hover 감지를 위해 position: relative를 제공 */
declare const ContextMenuItem: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
/** 메뉴 항목 버튼. $danger=true 이면 destructive 색상 적용 */
declare const ContextMenuButton: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, {
    $danger?: boolean;
}>> & string;
/** cursor 위치에 fixed 배치되는 서브메뉴 컨테이너 */
declare const ContextMenuSub: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, Omit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React$1.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React$1.RefObject<HTMLDivElement> | null | undefined;
}>, {
    $left: number;
    $top: number;
}>, {
    $left: number;
    $top: number;
}>> & string;
/** 서브메뉴 내 항목 버튼. $color로 개별 색상 지정 가능 */
declare const ContextMenuSubItem: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, {
    $color?: string;
}>> & string;

interface ContextMenuWithSubmenusAction {
    key: string;
    label: string;
    tone?: 'default' | 'danger';
    disabled?: boolean;
    onClick?: () => void;
    subActions?: ContextMenuWithSubmenusAction[];
    separator?: boolean;
}
interface ContextMenuWithSubmenusProps {
    anchorEl: HTMLElement | null;
    onClose: () => void;
    actions: ContextMenuWithSubmenusAction[];
    offset?: number;
    defaultOpenSubmenuKey?: string;
    alignRight?: boolean;
}
declare function ContextMenuWithSubmenus({ anchorEl, onClose, actions, offset, defaultOpenSubmenuKey, alignRight, }: ContextMenuWithSubmenusProps): react_jsx_runtime.JSX.Element | null;

type FloatingOverlayVariant = 'tooltip' | 'menu';
interface FloatingOverlayProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
    top: number;
    left: number;
    variant?: FloatingOverlayVariant;
    children: ReactNode;
}
/**
 * Fixed-position floating surface used by tooltips, hover cards, and menus.
 * Caller controls top/left positioning; variant toggles z-index + pointer-events.
 * Width/padding/min-width/etc. are passed via `style` to keep this primitive small.
 */
declare const FloatingOverlay: React$1.ForwardRefExoticComponent<FloatingOverlayProps & React$1.RefAttributes<HTMLDivElement>>;

type Placement = 'right' | 'left' | 'top' | 'bottom';
interface HoverPreviewProps {
    preview: React__default.ReactNode;
    delay?: number;
    offset?: number;
    placement?: Placement;
    disabled?: boolean;
    /** open 시 wrapped child 에 적용할 transform scale (기본 1 — 적용 안 함) */
    scale?: number;
    children: React__default.ReactNode;
    className?: string;
}
declare function HoverPreview({ preview, delay, offset, placement, disabled, scale, children, className, }: HoverPreviewProps): react_jsx_runtime.JSX.Element;

interface HelpTooltipProps {
    text: string;
    className?: string;
}
/**
 * 작은 "?" 아이콘 + hover 시 표시되는 텍스트 tooltip.
 * tooltip 은 `Tooltip`(createPortal + position: fixed)을 통해 렌더되어
 * 부모의 `overflow` / `transform` 에 잘리지 않는다.
 */
declare function HelpTooltip({ text, className }: HelpTooltipProps): react_jsx_runtime.JSX.Element;

interface TextInputDialogProps {
    open: boolean;
    value: string;
    onChange: (value: string) => void;
    onClose: () => void;
    onConfirm: () => void;
    title?: string;
    placeholder?: string;
    confirmLabel?: string;
    cancelLabel?: string;
    autoFocus?: boolean;
    /** Confirm 버튼 비활성화 조건 — 기본 trim 후 빈 문자열. */
    isInvalid?: (value: string) => boolean;
}
/**
 * Single text input + Confirm/Cancel 의 dialog.
 * Enter = Confirm, Escape = Close.
 * Class / dataset / tag 등 단순 이름 입력에 generic.
 */
declare function TextInputDialog({ open, value, onChange, onClose, onConfirm, title, placeholder, confirmLabel, cancelLabel, autoFocus, isInvalid, }: TextInputDialogProps): react_jsx_runtime.JSX.Element | null;

type MenuItemTone = 'default' | 'danger';
type MenuItemSize = 'sm' | 'md';
interface MenuItemProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    tone?: MenuItemTone;
    size?: MenuItemSize;
    active?: boolean;
    iconLeading?: ReactNode;
    iconTrailing?: ReactNode;
    children: ReactNode;
}
/**
 * Menu / dropdown / option list row. Rendered as a `<button>` for keyboard semantics —
 * caller sets `role="menuitem"` or `role="option"` as appropriate.
 * Hover paints with interactive-hover; `active` indicates the current selection
 * (tinted bg + accent text). `tone="danger"` colors destructive entries.
 */
declare const MenuItem: React$1.ForwardRefExoticComponent<MenuItemProps & React$1.RefAttributes<HTMLButtonElement>>;

interface TooltipProps {
    /** Tooltip text or node shown on hover */
    content: React__default.ReactNode;
    /** The element that triggers the tooltip */
    children: React__default.ReactNode;
    /** Gap between trigger bottom and tooltip top (px). Default: 6 */
    gap?: number;
}
/**
 * Hover-triggered tooltip rendered via `createPortal(document.body)` so its
 * `position: fixed` is anchored to the viewport regardless of any ancestor
 * with `transform` / `filter` / `perspective` / `will-change` (which would
 * otherwise become the containing block per CSS spec).
 *
 * Mount happens only while open — avoids stale hidden bubbles in `document.body`.
 */
declare const Tooltip: React__default.FC<TooltipProps>;

interface FilterPopoverProps extends React__default.HTMLAttributes<HTMLDivElement> {
    /** anchor coordinates → fixed positioning + viewport-bounded max-height */
    anchor?: {
        top: number;
        left: number;
    };
    /** popover width in px. default popupSizeNumbers.sm (280) */
    width?: number;
}
declare const FilterPopover: React__default.ForwardRefExoticComponent<FilterPopoverProps & React__default.RefAttributes<HTMLDivElement>>;

interface FilterPopoverSectionProps {
    title: string;
    /** Optional right-aligned actions (Select all, Reset, etc.) */
    actions?: React__default.ReactNode;
    children: React__default.ReactNode;
    className?: string;
}
declare function FilterPopoverSection({ title, actions, children, className }: FilterPopoverSectionProps): react_jsx_runtime.JSX.Element;

interface DuplicateItemModalProps {
    open: boolean;
    onClose: () => void;
    onSubmit: (payload: {
        name: string;
        optionChecked: boolean;
    }) => void;
    defaultName: string;
    submitting?: boolean;
    title?: string;
    nameLabel?: string;
    submitLabel?: string;
    submittingLabel?: string;
    option?: {
        label: string;
        defaultChecked?: boolean;
    };
}
declare function DuplicateItemModal({ open, onClose, onSubmit, defaultName, submitting, title, nameLabel, submitLabel, submittingLabel, option, }: DuplicateItemModalProps): react_jsx_runtime.JSX.Element | null;

interface ImageContextMenuItem {
    key: string;
    label: string;
    onClick?: () => void;
    disabled?: boolean;
}
interface ImageContextMenuProps {
    position: {
        top: number;
        left: number;
    } | null;
    items: ImageContextMenuItem[];
    onClose: () => void;
}
declare function ImageContextMenu({ position, items, onClose }: ImageContextMenuProps): React$1.ReactPortal | null;

type TableColumn<T> = {
    key: string;
    header: string;
    /** 고정 컬럼 너비 (px 또는 CSS 길이). */
    width?: string | number;
    /** Right-align cell + header, tabular-nums (숫자 정렬). */
    numeric?: boolean;
    /** 회색 텍스트 (보조 정보 컬럼). */
    muted?: boolean;
    /** Monospace 폰트 (token / UID 같은 코드 표시). */
    mono?: boolean;
    render: (row: T) => React__default.ReactNode;
};
type TableProps<T extends {
    id?: string | number;
}> = {
    columns: TableColumn<T>[];
    rows: T[];
    /** Row click handler */
    onRowClick?: (row: T, index: number) => void;
    /** Enable drag-to-reorder rows. Default: false */
    draggable?: boolean;
    /** Called when rows are reordered via drag. Only fires when draggable=true */
    onReorder?: (rows: T[]) => void;
    /** Estimated row height in px for drag calculation. Default: 48 */
    rowHeight?: number;
    /** Accessible label for the table's scrollable region. Required when multiple tables on a page. */
    ariaLabel?: string;
    /** Footer row (tfoot). Length should match columns.length. 각 column 의 numeric/mono prop 이 그대로 적용됨. */
    footer?: React__default.ReactNode[];
};
declare function Table<T extends {
    id?: string | number;
}>({ columns, rows, onRowClick, draggable, onReorder, rowHeight, ariaLabel, footer, }: TableProps<T>): react_jsx_runtime.JSX.Element;
declare const DataGrid: typeof Table;

declare const SectionPanel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const ActionBar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;

interface GridContainerProps extends React__default.HTMLAttributes<HTMLDivElement> {
    minWidth?: number;
    columns?: number;
    gap?: number;
    children: React__default.ReactNode;
}
declare const GridContainer: React__default.ForwardRefExoticComponent<GridContainerProps & React__default.RefAttributes<HTMLDivElement>>;

interface SelectableGridCellProps extends React__default.HTMLAttributes<HTMLDivElement> {
    selected: boolean;
    draggable?: boolean;
    /** Accessible label for the cell action (e.g. "Select image 'foo.jpg'"). Caller 가 항상 지정 권장. */
    ariaLabel?: string;
    children: React__default.ReactNode;
}
declare const SelectableGridCell: React__default.ForwardRefExoticComponent<SelectableGridCellProps & React__default.RefAttributes<HTMLDivElement>>;

interface KeyValueRowProps {
    label: React__default.ReactNode;
    value: React__default.ReactNode;
    className?: string;
}
declare function KeyValueRow({ label, value, className }: KeyValueRowProps): react_jsx_runtime.JSX.Element;

interface LegendItemProps {
    color: string;
    label: React__default.ReactNode;
    className?: string;
}
declare function LegendItem({ color, label, className }: LegendItemProps): react_jsx_runtime.JSX.Element;

type Elevation = 'panel' | 'card' | 'raised';
interface CardProps extends React__default.HTMLAttributes<HTMLDivElement> {
    elevation?: Elevation;
    radius?: string;
    padding?: string;
    overflow?: 'visible' | 'hidden';
    children: React__default.ReactNode;
}
declare function Card({ elevation, radius, padding, overflow, children, ...rest }: CardProps): react_jsx_runtime.JSX.Element;

type ColorSwatchSize = 'xs' | 'sm' | 'md';
type ColorSwatchShape = 'circle' | 'square';
declare const ColorSwatch: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $color: string;
    $size?: ColorSwatchSize;
    $shape?: ColorSwatchShape;
}>> & string;

interface CommentItemProps {
    author: React__default.ReactNode;
    timestamp?: string;
    body: React__default.ReactNode;
    actions?: React__default.ReactNode;
}
declare function CommentItem({ author, timestamp, body, actions }: CommentItemProps): react_jsx_runtime.JSX.Element;
interface CommentInputProps {
    value: string;
    onChange: (value: string) => void;
    onSubmit?: () => void;
    placeholder?: string;
    submitLabel?: string;
    disabled?: boolean;
    maxLength?: number;
}
declare function CommentInput({ value, onChange, onSubmit, placeholder, submitLabel, disabled, maxLength, }: CommentInputProps): react_jsx_runtime.JSX.Element;

interface TagListItemProps extends Omit<React__default.ButtonHTMLAttributes<HTMLButtonElement>, 'color'> {
    color: string;
    label: React__default.ReactNode;
    active?: boolean;
    count?: number;
}
declare const TagListItem: React__default.ForwardRefExoticComponent<TagListItemProps & React__default.RefAttributes<HTMLButtonElement>>;

interface TagItemData {
    id: string;
    color: string;
    label: string;
    count?: number;
}
interface TagListProps {
    items: TagItemData[];
    selectedId?: string | null;
    activeIds?: Set<string>;
    onItemClick?: (id: string) => void;
    className?: string;
}
declare function TagList({ items, selectedId, activeIds, onItemClick, className }: TagListProps): react_jsx_runtime.JSX.Element;

interface TagSearchCandidate {
    id: string;
    color: string;
    label: string;
}
interface TagListSearchProps {
    placeholder?: string;
    candidates: TagSearchCandidate[];
    onSelect: (id: string) => void;
    emptyMessage?: string;
    emptyAction?: {
        label: string;
        onClick: () => void;
    };
    className?: string;
}
declare function TagListSearch({ placeholder, candidates, onSelect, emptyMessage, emptyAction, className, }: TagListSearchProps): react_jsx_runtime.JSX.Element;

interface SearchableListProps<T> {
    candidates: T[];
    onSelect: (item: T) => void;
    getKey: (item: T) => string;
    renderItem: (item: T, onClick: () => void) => React.ReactNode;
    filter?: (item: T, query: string) => boolean;
    placeholder?: string;
    emptyMessage?: string;
    emptyAction?: {
        label: string;
        onClick: () => void;
    };
    className?: string;
}
declare function SearchableList<T>({ candidates, onSelect, getKey, renderItem, filter, placeholder, emptyMessage, emptyAction, className, }: SearchableListProps<T>): react_jsx_runtime.JSX.Element;

interface ImageViewerContextValue {
    zoom: number;
    containerWidth: number;
    containerHeight: number;
}
declare const ImageViewerContext: React__default.Context<ImageViewerContextValue | null>;
interface ImageViewerProps {
    src: string;
    alt?: string;
    zoomOptions?: UseZoomPanOptions;
    onZoomChange?: (zoom: number) => void;
    /** Overlay layer (e.g. DrawingLayer) rendered on top of the image */
    children?: React__default.ReactNode;
    className?: string;
}
declare function ImageViewer({ src, alt, zoomOptions, onZoomChange, children, className, }: ImageViewerProps): react_jsx_runtime.JSX.Element;

interface ResizablePanelProps {
    direction?: 'horizontal' | 'vertical';
    defaultSize?: number;
    minSize?: number;
    maxSize?: number;
    storageKey?: string;
    children: [React__default.ReactNode, React__default.ReactNode];
    className?: string;
}
declare function ResizablePanel({ direction, defaultSize, minSize, maxSize, storageKey, children, className, }: ResizablePanelProps): react_jsx_runtime.JSX.Element;

interface ActionChipProps extends Omit<React__default.ButtonHTMLAttributes<HTMLButtonElement>, 'color'> {
    /** Optional color swatch (xs size) displayed before the label. */
    color?: string;
    /** Chip label. */
    children: React__default.ReactNode;
}
/**
 * Interactive pill chip with optional color swatch + label. Used in chip groups
 * (`ChipGroup`), tag selectors, filter rows. For static (non-interactive) tag
 * display, use `Chip` (feedback) which is span-based.
 */
declare const ActionChip: React__default.ForwardRefExoticComponent<ActionChipProps & React__default.RefAttributes<HTMLButtonElement>>;

interface KeyboardShortcutHintProps {
    keys: string[];
    size?: 'sm' | 'md';
    className?: string;
}
declare function KeyboardShortcutHint({ keys, size, className }: KeyboardShortcutHintProps): react_jsx_runtime.JSX.Element;

declare const InfoRow: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const InfoRowLabel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;
declare const InfoRowValue: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;

interface InfoSectionProps {
    title: string;
    children: ReactNode;
    className?: string;
}
/**
 * 작은 uppercase title + 자식 content 의 section.
 * 사이드바 / 패널 안의 도메인 정보 묶음에 generic.
 */
declare function InfoSection({ title, children, className }: InfoSectionProps): react_jsx_runtime.JSX.Element;

interface LabeledSwatchRowProps {
    id: string;
    label: string;
    color: string;
    count?: number;
    selected?: boolean;
    onClick?: (id: string) => void;
}
/**
 * Color swatch + label + optional count 의 selectable list item.
 * Selected 상태에서 accent border-left + accent-soft-surface 배경.
 * Class / category / tag 등 색 매핑된 항목 리스트에 generic.
 */
declare function LabeledSwatchRow({ id, label, color, count, selected, onClick }: LabeledSwatchRowProps): react_jsx_runtime.JSX.Element;

interface SwatchItem {
    id: string;
    label: string;
    color: string;
    count?: number;
}
interface SwatchItemListProps {
    items: SwatchItem[];
    onRemove?: (id: string) => void;
    onHover?: (id: string | null) => void;
    removeIcon?: React__default.ReactNode;
    className?: string;
}
/**
 * Color swatch + label + optional count + (옵셔널) remove 버튼 의 inline list.
 * 각 row 는 hover background. 도메인 class / tag / category pool 등에 generic.
 */
declare function SwatchItemList({ items, onRemove, onHover, removeIcon, className }: SwatchItemListProps): react_jsx_runtime.JSX.Element;

interface UserPoolItem {
    id: string;
    label: string;
    tooltip?: string;
}
interface UserPoolListProps {
    users: UserPoolItem[];
    selectedIds: Set<string>;
    onToggle: (id: string) => void;
    onHover?: (id: string | null) => void;
    title?: string;
    defaultOpen?: boolean;
    className?: string;
}
declare function UserPoolList({ users, selectedIds, onToggle, onHover, title, defaultOpen, className, }: UserPoolListProps): react_jsx_runtime.JSX.Element | null;

interface DetailPanelSidebarProps {
    /** 고정된 상단 슬롯. flex-shrink:0. */
    headerSlot: ReactNode;
    /** 가운데 — 남은 공간을 차지하고 내부 스크롤. 없으면 미렌더. */
    bodySlot?: ReactNode;
    /** body 슬롯 상단의 섹션 타이틀. */
    bodySectionTitle?: string;
    /**
     * 하단 고정 슬롯 배열. 각 항목이 자체 FixedSection 으로 렌더된다.
     * 자체 header 를 가지는 콘텐츠가 들어오는 것을 가정해 wrapper 가 title 을 추가하지 않음.
     */
    footerSlots?: ReactNode[];
    className?: string;
}
declare function DetailPanelSidebar({ headerSlot, bodySlot, bodySectionTitle, footerSlots, className, }: DetailPanelSidebarProps): react_jsx_runtime.JSX.Element;

interface MobileShellProps {
    topBar: ReactNode;
    body: ReactNode;
    bottomBar?: ReactNode;
}
declare function MobileShell({ topBar, body, bottomBar }: MobileShellProps): react_jsx_runtime.JSX.Element;

interface SidePanelLayoutSection {
    title: ReactNode;
    headerActions?: ReactNode;
    body: ReactNode;
}
interface SidePanelLayoutProps {
    sections: SidePanelLayoutSection[];
    className?: string;
}
declare function SidePanelLayout({ sections, className }: SidePanelLayoutProps): react_jsx_runtime.JSX.Element;

interface CollapsibleSectionHeaderProps {
    title: string;
    open: boolean;
    onClick: () => void;
    badge?: ReactNode;
    className?: string;
}
/**
 * Section header with chevron + uppercase label + optional trailing badge,
 * rendered as a `<button>` so it can toggle a collapsible body.
 * Used by sidebar panels (Comments, Labelers, etc.).
 */
declare function CollapsibleSectionHeader({ title, open, onClick, badge, className, }: CollapsibleSectionHeaderProps): react_jsx_runtime.JSX.Element;

type AspectRatio = '1/1' | '4/3' | '16/9' | '16/10';
interface AspectRatioImageProps extends Omit<ImgHTMLAttributes<HTMLImageElement>, 'alt'> {
    ratio?: AspectRatio;
    alt?: string;
    children?: ReactNode;
}
/**
 * Fixed-ratio thumbnail frame. Renders an `<img>` with `object-fit: cover` over a
 * subtle gradient fallback so the cell never goes empty during load.
 * Pass overlay slots (badges, OverlayLayer) as children — they layer above the image.
 */
declare function AspectRatioImage({ ratio, alt, children, ...imgProps }: AspectRatioImageProps): react_jsx_runtime.JSX.Element;

interface ImageCardImage {
    id: string;
    name: string;
    thumb_url: string;
    archived?: boolean;
    processing?: boolean;
    group_count?: number;
}
interface ImageCardProps {
    image: ImageCardImage;
    selected?: boolean;
    showName?: boolean;
    showKebab?: boolean;
    /** 우상단 슬롯 (kebab 좌측). sync 상태 칩 등을 외부 도메인에서 주입 */
    topRightSlot?: ReactNode;
    onSelect?: (id: string, e: React__default.MouseEvent) => void;
    onOpen?: (id: string) => void;
    onOpenMenu?: (id: string, anchor: HTMLElement) => void;
}
declare function ImageCard({ image, selected, showName, showKebab, topRightSlot, onSelect, onOpen, onOpenMenu, }: ImageCardProps): react_jsx_runtime.JSX.Element;

type VideoAspectRatio = '1/1' | '4/3' | '16/9' | '16/10' | '9/16';
interface VideoPlayerProps extends Omit<VideoHTMLAttributes<HTMLVideoElement>, 'children'> {
    src: string;
    poster?: string;
    ratio?: VideoAspectRatio;
    controls?: boolean;
}
/**
 * 토큰 기반 HTML5 비디오 래퍼. 토글 가능한 `ratio` 로 frame 비율을 잡고
 * 내부 `<video>` 는 cover 로 렌더링한다.
 */
declare function VideoPlayer({ src, poster, ratio, controls, ...rest }: VideoPlayerProps): react_jsx_runtime.JSX.Element;

interface ResizableColumn {
    /** px 너비 (number) 또는 'auto' (flex:1 — 한 컬럼만 가능). */
    width: number | 'auto';
    /** drag-to-resize 핸들 표시. auto 컬럼은 무시됨. */
    resizable?: boolean;
    /** min/max 제한 (resize 시). */
    minWidth?: number;
    maxWidth?: number;
    /** collapse 시 width 0 + transition. 외부 제어 (controlled). */
    collapsed?: boolean;
    /** 아예 안 보이게. 컬럼/핸들 모두 미렌더. (예: 옵셔널 inspector). */
    hidden?: boolean;
    /** Column 표면 배경색 (optional). */
    background?: string;
}
interface ResizableColumnsLayoutProps {
    /** N 컬럼 정의. 정확히 한 컬럼만 `width: 'auto'` 가능. */
    columns: ResizableColumn[];
    /** children.length === columns.length. 각 child 가 한 컬럼에 매핑. */
    children: React__default.ReactNode;
    /** localStorage 에 각 컬럼 width 를 `${storageKey}-${i}` 형식으로 저장. */
    storageKey?: string;
    className?: string;
    style?: React__default.CSSProperties;
}
/**
 * N-column 유연 layout. 각 컬럼은 고정 px 또는 'auto' (flex:1). resizable 컬럼은
 * 옆에 ResizeHandle 표시 + drag 로 width 조정. localStorage 로 width 영속화 지원.
 *
 * Drag 방향은 auto 컬럼 기준 자동 결정: auto 왼쪽 컬럼은 +delta, 오른쪽은 -delta.
 *
 * 정적 grid layout 은 SplitLayout / DashboardGrid / ListDetailLayout (patterns/layouts) 사용.
 */
declare function ResizableColumnsLayout({ columns, children, storageKey, className, style, }: ResizableColumnsLayoutProps): react_jsx_runtime.JSX.Element;

type OverlayLayerProps = HTMLAttributes<HTMLDivElement>;
/**
 * Full-fill absolute layer for placing interactive elements on top of an image/canvas.
 * The wrapper passes pointer events through; children opt back in via the `> *` rule,
 * so the underlying surface remains clickable except where overlay children sit.
 */
declare function OverlayLayer(props: OverlayLayerProps): react_jsx_runtime.JSX.Element;

type SelectableListItemVariant = 'flat' | 'card';
interface SelectableListItemProps extends Omit<React__default.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    variant?: SelectableListItemVariant;
    selected?: boolean;
    dragOver?: boolean;
    /** Render element. default 'button' (clickable). use 'li' for semantic list rows. */
    as?: 'button' | 'li';
    'data-ig-component'?: string;
    'data-ig-slot'?: string;
    children: React__default.ReactNode;
}
declare const SelectableListItem: React__default.ForwardRefExoticComponent<SelectableListItemProps & React__default.RefAttributes<HTMLElement>>;

interface OptionRowProps extends React__default.ButtonHTMLAttributes<HTMLButtonElement> {
    primary: React__default.ReactNode;
    secondary?: React__default.ReactNode;
    actionLabel: React__default.ReactNode;
}
declare const OptionRow: React__default.ForwardRefExoticComponent<OptionRowProps & React__default.RefAttributes<HTMLButtonElement>>;

/**
 * Static small tag visual. Generic atomic — caller controls bg / color.
 *
 * For interactive button-like chips, use `ActionChip`.
 * For Badge-shaped (pill, larger) tags, use `Badge` / `Chip` from feedback.
 */
declare const Tag: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React$1.DetailedHTMLProps<React$1.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $bg: string;
    $color: string;
}>> & string;

declare const icons: {
    readonly activity: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly alertCircle: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly barChart3: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly camera: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly checkCircle: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly chevronRight: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly fileText: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly filter: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly globe: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly grid3x3: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly image: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly info: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly layers: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly layoutGrid: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly lineChart: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly maximize: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly pieChart: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly qrCode: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly refreshCw: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly search: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly settings: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly shuffle: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly table: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly users: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly wifi: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly wifiOff: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
    readonly x: React$1.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & React$1.RefAttributes<SVGSVGElement>>;
};
type IconName = keyof typeof icons;

declare function IconGallery({ names, size, }: {
    names?: IconName[];
    size?: number;
}): react_jsx_runtime.JSX.Element;

declare function ChartLegend({ items, }: {
    items: Array<{
        label: string;
        color: string;
    }>;
}): react_jsx_runtime.JSX.Element;

declare function ChartTooltipContent({ active, label, payload, }: {
    active?: boolean;
    label?: string;
    payload?: Array<{
        name?: string;
        value?: string | number;
        color?: string;
    }>;
}): react_jsx_runtime.JSX.Element | null;

declare function ChartResponsive({ height, minWidth, children, }: {
    height: number;
    minWidth?: number;
    children: (size: {
        width: number;
        height: number;
    }) => React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

interface SafeResponsiveContainerProps {
    /** 단일 자식 Recharts root (BarChart / LineChart / PieChart 등). `width` / `height` prop 이 자동 주입됨. */
    children: React__default.ReactElement;
    className?: string;
    style?: React__default.CSSProperties;
}
/**
 * Recharts `ResponsiveContainer` 의 안정 대체. `useElementSize` 로
 * 컨테이너 크기 변화를 감지하고 자식에게 `width` / `height` 를 cloneElement 로 전달.
 *
 * ResponsiveContainer 가 특정 layout 조합 (grid + min-height:0 + transition 등) 에서
 * size 0 을 반복 보고하는 버그를 회피.
 */
declare function SafeResponsiveContainer({ children, className, style }: SafeResponsiveContainerProps): react_jsx_runtime.JSX.Element;

interface PieSliceLabelProps {
    cx?: number;
    cy?: number;
    midAngle?: number;
    innerRadius?: number;
    outerRadius?: number;
    percent?: number;
    name?: string;
    value?: number;
}
/**
 * Recharts `<Pie label={renderPieSliceLabel}>` 호환 — 슬라이스 중앙에 name + value 2줄.
 * percent < 6% 은 라벨 생략.
 */
declare function renderPieSliceLabel(props: PieSliceLabelProps): react_jsx_runtime.JSX.Element | null;

export { ActionBar, ActionChip, type ActionChipProps, Alert, type AspectRatio, AspectRatioImage, type AspectRatioImageProps, Avatar, Badge, Breadcrumbs, Button, type ButtonProps, type ButtonSize, type ButtonTone, type ButtonVariant, Card, type CardProps, ChartLegend, ChartResponsive, ChartTooltipContent, Checkbox, Chip, ChipTabs, type ChipTabsItem, type ChipTabsProps, CollapsibleSectionHeader, type CollapsibleSectionHeaderProps, ColorChip, type ColorChipProps, ColorInput, type ColorInputProps, ColorSwatch, type ColorSwatchShape, type ColorSwatchSize, CommentInput, type CommentInputProps, CommentItem, type CommentItemProps, CompactModalCard, ConfirmDialog, ContextMenuBackdrop, ContextMenuButton, ContextMenuItem, ContextMenuList, ContextMenuSub, ContextMenuSubItem, ContextMenuWithSubmenus, type ContextMenuWithSubmenusAction, type ContextMenuWithSubmenusProps, CopyButton, type CopyButtonProps, DataGrid, DatePickerField, type DatePickerProps, DateRangePicker, type DateRangePickerPreset, type DateRangePickerProps, type DateRangePickerValue, DefaultErrorFallback, type DefaultErrorFallbackProps, DetailPanelSidebar, type DetailPanelSidebarProps, DialogCloseButton, DialogShell, DragHandle, type DragHandleProps, Drawer, DrawingObject, DropZone, type DropZoneProps, type DropZoneVariant, type DropdownOption, DropdownSelect, DuplicateItemModal, type DuplicateItemModalProps, type ElementSize, EmptyState, type EmptyStateProps, ErrorBoundary, type ErrorBoundaryProps, FieldRow, type FieldRowProps, FileInput, FilterBarLayout, type FilterBarLayoutProps, type FilterChipItem, FilterChipRow, type FilterChipRowProps, FilterPopover, type FilterPopoverProps, FilterPopoverSection, type FilterPopoverSectionProps, FilterPopoverTrigger, type FilterPopoverTriggerProps, FloatingOverlay, type FloatingOverlayProps, type FloatingOverlayVariant, FloatingPanelField, type FloatingPanelFieldProps, FormField, type FormFieldProps, GridContainer, type GridContainerProps, GroupCountBadge, type GroupCountBadgeProps, HelpTooltip, type HelpTooltipProps, HoverCard, HoverPreview, type HoverPreviewProps, IconButton, IconGallery, type IconName, ImageCard, type ImageCardImage, type ImageCardProps, ImageContextMenu, type ImageContextMenuItem, type ImageContextMenuProps, ImageViewer, ImageViewerContext, type ImageViewerContextValue, type ImageViewerProps, IndexedNavigation, type IndexedNavigationProps, InfoRow, InfoRowLabel, InfoRowValue, InfoSection, type InfoSectionProps, InlineMessage, InputAdornment, type InputAdornmentProps, KeyValueRow, type KeyValueRowProps, KeyboardShortcutHint, type KeyboardShortcutHintProps, LabeledSwatchRow, type LabeledSwatchRowProps, type LegacyButtonVariant, LegendItem, type LegendItemProps, MediaOverlay, type MediaOverlayProps, type MediaOverlayVariant, type MentionCandidate, MentionTextarea, type MentionTextareaProps, Menu, MenuItem, type MenuItemProps, type MenuItemSize, type MenuItemTone, MenuPopover, type MenuPopoverProps, MobileBottomToolbar, type MobileBottomToolbarAction, type MobileBottomToolbarProps, MobileDropdown, type MobileDropdownOption, type MobileDropdownProps, MobileNavShell, type MobileNavShellItem, type MobileNavShellProps, MobileShell, type MobileShellProps, ModalActions, ModalBackdrop, ModalCard, ModalHeader, ModalTitle, ModeSwitcher, type ModeSwitcherOption, type ModeSwitcherProps, type NormalizedCoord, NotificationBadge, NotificationBubble, NumberField, type NumberFieldProps, OptionRow, type OptionRowProps, OverlayLayer, type OverlayLayerProps, Pagination, PasswordField, type PieSliceLabelProps, PopoverCard, PopoverTriggerField, type PopoverTriggerFieldProps, ProgressBar, ProgressFill, type ProgressSegment, ProgressTrack, Radio, RadioCardGroup, type RadioCardGroupOption, type RadioCardGroupOrientation, type RadioCardGroupProps, type ResizableColumn, ResizableColumnsLayout, type ResizableColumnsLayoutProps, ResizablePanel, type ResizablePanelProps, ResizeHandle, type ResizeHandleOrientation, type ResizeHandleProps, SafeResponsiveContainer, type SafeResponsiveContainerProps, SearchField, type SearchFieldProps, SearchableList, type SearchableListProps, SectionPanel, SegmentedControl, type SegmentedControlOption, type SegmentedControlProps, SegmentedProgressBar, type SegmentedProgressBarProps, SelectField, type SelectFieldProps, SelectableGridCell, type SelectableGridCellProps, SelectableListItem, type SelectableListItemProps, type SelectableListItemVariant, type SelectionAction, SelectionActionBar, type SelectionActionBarProps, SidePanelLayout, type SidePanelLayoutProps, type SidePanelLayoutSection, Skeleton, SmallText, Spinner, type SpinnerProps, type SpinnerSize, type SpinnerTone, StateChip, type StateChipProps, type StateChipStyle, StatusPill, StatusTone, StepIndicator, type StepIndicatorProps, type StepItem, type StepStatus, Stepper, type SwatchItem, SwatchItemList, type SwatchItemListProps, Switch, Table, type TableColumn, type TableProps, Tabs, TabsNav, Tag, type TagItemData, TagList, TagListItem, type TagListItemProps, type TagListProps, TagListSearch, type TagListSearchProps, type TagSearchCandidate, TextButton, type TextButtonProps, type TextButtonSize, type TextButtonTone, TextField, type TextFieldProps, type TextFieldSize, TextInputDialog, type TextInputDialogProps, Textarea, TextareaField, type TextareaProps, type TextareaVariant, type ToastAction, type ToastItem, ToastProvider, type ToastTone, ToolbarShell, type ToolbarShellAction, type ToolbarShellProps, Tooltip, TooltipBubble, TooltipCard, type TooltipCardProps, type TooltipProps, TwoColumnDialog, type TwoColumnDialogProps, UploadDropzone, type UploadDropzoneProps, type UseCanvasMouseConfig, type UseClickOutsideOptions, type UseClipboardOptions, type UseElementSizeOptions, type UseUndoRedoOptions, type UseZoomInvariantRendererOptions, type UseZoomPanOptions, type UserPoolItem, UserPoolList, type UserPoolListProps, VerticalTabs, type VerticalTabsItem, type VerticalTabsRadius, type VideoAspectRatio, VideoPlayer, type VideoPlayerProps, type ZoomInvariantRendererCtx, buttonPadding, getNormalizedCoord, icons, normalizeVariant, renderPieSliceLabel, useCanvasMouse, useClickOutside, useClipboard, useElementSize, useSelection, useToast, useUndoRedo, useZoomInvariantRenderer, useZoomPan };
