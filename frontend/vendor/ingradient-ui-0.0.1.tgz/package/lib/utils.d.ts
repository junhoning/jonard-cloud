export { F as FormatPatternTabItem, f as formatPatternTab } from './format-pattern-tab-BNsFrTcn.js';

/**
 * Environment-aware logger — debug/log calls are no-ops in production builds.
 * Detects dev mode from either Vite (`import.meta.env.DEV`) or Node-shaped
 * environments (`process.env.NODE_ENV === 'development'`).
 *
 * Usage:
 *   import { logger } from '@ingradient/ui'
 *   logger.debug('[MyModule]', 'verbose info', data)
 *   logger.warn('[MyModule]', 'something fishy', err)
 */
declare const logger: {
    debug: (..._args: unknown[]) => void;
    log: (..._args: unknown[]) => void;
    info: (...data: any[]) => void;
    warn: (...data: any[]) => void;
    error: (...data: any[]) => void;
};

/**
 * Compute summary checkbox state for a group of atomic permission keys.
 * - All keys true → checked
 * - All keys false → unchecked (indeterminate=false)
 * - Mixed → indeterminate
 */
declare function getSummaryPermissionState(rolePermissions: Record<string, boolean>, permissionKeys: string[]): {
    checked: boolean;
    indeterminate: boolean;
};

interface DownloadCaptureOptions {
    /** PNG 배경색. 기본 `chartColors.canvasExportBg` (#181818). */
    backgroundColor?: string;
    /** 파일명에 사용할 title. slug 화 후 `.png` 가 붙음. */
    title: string;
    /** 캡쳐 시 제외할 노드 판별. true 반환 시 포함. 기본은 `data-download-hide` 속성 없으면 포함. */
    filter?: (node: HTMLElement) => boolean;
}
/**
 * DOM node 를 PNG 로 캡쳐 후 자동 다운로드.
 * - device pixel ratio 를 max 3 까지 사용 (선명도)
 * - `data-download-hide` 속성이 있는 자식 노드는 기본 필터로 제외
 * - container 가 null 이면 no-op
 */
declare function downloadCaptureAsPng(container: HTMLElement | null, options: DownloadCaptureOptions): Promise<void>;

/**
 * Recharts Tooltip 의 `formatter` prop 호환 — 값을 toLocaleString 으로 포맷.
 * Returns [valueString, suffix] tuple.
 */
declare function formatTooltipValue(value: number | string | readonly (number | string)[] | undefined, suffix?: string): [string, string];
/**
 * ms 단위 duration 을 `123 ms` 또는 `1.23 s` 로 포맷. null/NaN 은 em-dash.
 */
declare function formatDurationMs(value: number | null | undefined): string;

/**
 * Compute the `object-fit: cover` square crop region in normalized image coords.
 * Returns the (vx, vy, vw, vh) slice of the [0, 1] image that is visible after
 * the thumbnail crops to a square.
 *
 * - landscape (ar > 1): horizontal slice (width 1/ar centered)
 * - portrait (ar < 1): vertical slice (height ar centered)
 * - square or unknown: full [0, 1] view
 */
declare function coverCropRegion(imageWidth: number, imageHeight: number): {
    vx: number;
    vy: number;
    vw: number;
    vh: number;
};

export { type DownloadCaptureOptions, coverCropRegion, downloadCaptureAsPng, formatDurationMs, formatTooltipValue, getSummaryPermissionState, logger };
